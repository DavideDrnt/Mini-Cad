package is.specificcommand;

import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import is.command.Command;
import is.interpreter.IdGroups;
import is.shapes.model.AbstractGraphicObject;

public class UnGroupCommand implements Command{
	
	private List<AbstractGraphicObject> gruppo;
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	private IdGroups idGroups;
	
	private int idDaRimuovere;
	
	public UnGroupCommand(int idGrp, Map<Integer, List<AbstractGraphicObject>> gruppi, 
			IdGroups idGroups) {
		this.gruppi = gruppi;
		this.idGroups = idGroups;
		this.idDaRimuovere = idGrp;
	}

	@Override
	public boolean doIt() {
		gruppo = gruppi.remove(idDaRimuovere);
		if(idDaRimuovere == (idGroups.getNextGrpId() - 1)) {
			idGroups.decrementa();;
		}
		JOptionPane.showMessageDialog(null, "Gruppo gid_"+idDaRimuovere+" rimosso.");
		
		return true;
	}

	@Override
	public boolean undoIt() {
		if(gruppo != null) {
			gruppi.put(idDaRimuovere, gruppo);
			if(idDaRimuovere == idGroups.getNextGrpId()) {
				idGroups.incrementa();;
			}
			JOptionPane.showMessageDialog(null, "Gruppo gid_"+idDaRimuovere+" ricreato.");
			}
		return true;
	}
	

}
