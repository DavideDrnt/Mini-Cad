package is.specificcommand;

import static org.junit.Assert.*;

import java.awt.Point;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import is.interpreter.Opzioni;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.RectangleObject;
import is.shapes.view.GraphicObjectPanel;

public class PerimeterCommandTest {
	private static GraphicObjectPanel gpanel;
	private static List<AbstractGraphicObject> listObj;
	private static Map<Integer, List<AbstractGraphicObject>> gruppi ;

	private int id;
	private Opzioni opt;
	private String type;
	
	
	private PerimeterCommand perimeter;
	
	@Before
	public void init() {
		gpanel = new GraphicObjectPanel();
		listObj = new LinkedList<>();
		gruppi = new HashMap<>();
	}
	
	
/////// 	I TEST VISUALIZZERANNO SU SCHERMO 2 VOLTE I MESSAGGI CON LA LISTA DELLE PROPRIETA' /////////
///////		PERCHE' ALLA CREAZIONE DEL COMANDO SI EFFETTUA UNA CHIAMATA DEL METODO doIt() /////////
///////		PER VERIFICARE LA CORRETTEZZA DEL TEST L'HO DOVUTO RICHIAMARE	/////////
	
	
	@Test
	public void testObj() {
		CircleObject c = new CircleObject(new Point(80,80), 23.0);
		gpanel.add(c);
		listObj.add(c);
		c.setID(listObj.indexOf(c));
		id = c.getID();
		
		opt = Opzioni.SINGLE_OBJECT;
		
		perimeter = new PerimeterCommand(listObj, gruppi, gpanel, id, opt, type);
		assertTrue(perimeter.doIt());
		
	}
	
	@Test
	public void testGrp() {//passo l'id di un gruppo
		CircleObject c = new CircleObject(new Point(80,80), 23.0);
		CircleObject c1 = new CircleObject(new Point(30,30), 10.0);

		RectangleObject r = new RectangleObject(new Point(100,100), 23.0, 30.0);

		gpanel.add(c);gpanel.add(c1); gpanel.add(r);
		listObj.add(c); c.setID(listObj.indexOf(c));
		listObj.add(c1); c1.setID(listObj.indexOf(c1)); 
		listObj.add(r); r.setID(listObj.indexOf(r));
		
		LinkedList<AbstractGraphicObject> grp = new LinkedList<>();
		grp.add(c); grp.add(r);
		
		gruppi.put(0, grp);
		
		id = 0;
		
		opt = Opzioni.GRP;
		
		
		perimeter = new PerimeterCommand(listObj, gruppi, gpanel, id, opt, type);
		assertTrue(perimeter.doIt());
		
		
	}

	@Test
	public void testType() {
		CircleObject c = new CircleObject(new Point(80,80), 23.0);
		CircleObject c1 = new CircleObject(new Point(30,30), 10.0);

		RectangleObject r = new RectangleObject(new Point(100,100), 23.0, 30.0);

		gpanel.add(c);gpanel.add(c1); gpanel.add(r);
		listObj.add(c); c.setID(listObj.indexOf(c));
		listObj.add(c1); c1.setID(listObj.indexOf(c1)); 
		listObj.add(r); r.setID(listObj.indexOf(r));
		
		opt = Opzioni.TYPE;
		type = "circle";
		
		perimeter = new PerimeterCommand(listObj, gruppi, gpanel, id, opt, type);
		assertTrue(perimeter.doIt());
	}
	
	@Test
	public void testAll() {
		CircleObject c = new CircleObject(new Point(80,80), 23.0);
		CircleObject c1 = new CircleObject(new Point(30,30), 10.0);

		RectangleObject r = new RectangleObject(new Point(100,100), 23.0, 30.0);
		RectangleObject r1 = new RectangleObject(new Point(50,50), 2.0, 12.0);

		
		gpanel.add(c);gpanel.add(c1); gpanel.add(r);gpanel.add(r1);
		listObj.add(c); c.setID(listObj.indexOf(c));
		listObj.add(c1); c1.setID(listObj.indexOf(c1)); 
		listObj.add(r); r.setID(listObj.indexOf(r));
		listObj.add(r1); r1.setID(listObj.indexOf(r1));
		
		opt = Opzioni.ALL;
		perimeter = new PerimeterCommand(listObj, gruppi, gpanel, id, opt, type);
		assertTrue(perimeter.doIt());
		
	}
	
	@Test(expected = UnsupportedOperationException.class)
	public void testUndo() {
		CircleObject c = new CircleObject(new Point(80,80), 23.0);
		gpanel.add(c);
		listObj.add(c);
		id = c.getID();
		
		opt = Opzioni.SINGLE_OBJECT;
		
		perimeter = new PerimeterCommand(listObj, gruppi, gpanel, id, opt, type);
		perimeter.undoIt();
	}
	
	
	
}
