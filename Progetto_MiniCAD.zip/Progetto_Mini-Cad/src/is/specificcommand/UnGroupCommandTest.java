package is.specificcommand;

import static org.junit.Assert.*;

import java.awt.Point;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import is.interpreter.IdGroups;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.RectangleObject;

public class UnGroupCommandTest {

	private static List<AbstractGraphicObject> gruppo;
	private static Map<Integer, List<AbstractGraphicObject>> gruppi;
	private static IdGroups idGroups;
	private static int idDaRimuovere;
	
	private UnGroupCommand ungrp;
	
	@Before
	public void reset() {
		gruppo = new LinkedList<>();
		gruppi = new HashMap<>();
		idGroups = new IdGroups();
		
	}
	
	
	@Test
	public void ungrpDo() {
		CircleObject c0 = new CircleObject(new Point(89,99), 30.0);
		c0.setID(0);
		gruppo.add(c0);
		
		CircleObject c1 = new CircleObject(new Point(200,200), 23.0);
		c1.setID(1);
		gruppo.add(c1);
		
		RectangleObject r = new RectangleObject(new Point(20,30), 5.0, 12.0);
		r.setID(2);
		gruppo.add(r);
		
		gruppi.put(idGroups.getNextGrpId(), gruppo);
		idGroups.incrementa();
		idDaRimuovere = 0;
		
		ungrp = new UnGroupCommand(idDaRimuovere, gruppi, idGroups);
		ungrp.doIt();
		assertEquals(true, gruppi.isEmpty() && idGroups.getNextGrpId() == 0);
		
	}
	
	@Test
	public void ungrpUndo() {
		CircleObject c0 = new CircleObject(new Point(89,99), 30.0);
		c0.setID(0);
		gruppo.add(c0);
		
		CircleObject c1 = new CircleObject(new Point(200,200), 23.0);
		c1.setID(1);
		gruppo.add(c1);
		
		RectangleObject r = new RectangleObject(new Point(20,30), 5.0, 12.0);
		r.setID(2);
		gruppo.add(r);
		
		gruppi.put(idGroups.getNextGrpId(), gruppo);
		idGroups.incrementa();
		idDaRimuovere = 0;
		
		ungrp = new UnGroupCommand(idDaRimuovere, gruppi, idGroups);
		ungrp.doIt();
		ungrp.undoIt();
		assertEquals(true, !(gruppi.isEmpty()) && idGroups.getNextGrpId() == 1);
		
	}
	
	@Test
	public void ungrpDoMulti() {//faccio più ungrp
		CircleObject c0 = new CircleObject(new Point(89,99), 30.0);
		c0.setID(0);
		gruppo.add(c0);
		
		CircleObject c1 = new CircleObject(new Point(200,200), 23.0);
		c1.setID(1);
		gruppo.add(c1);
		
		RectangleObject r = new RectangleObject(new Point(20,30), 5.0, 12.0);
		r.setID(2);
		gruppo.add(r);
		
		List<AbstractGraphicObject> gruppo1 = new LinkedList<>();
		gruppo1.add(c0);gruppo1.add(r);
		
		gruppi.put(idGroups.getNextGrpId(), gruppo);
		idGroups.incrementa();
		
		gruppi.put(idGroups.getNextGrpId(), gruppo1);
		idGroups.incrementa();
		
		idDaRimuovere = 0;
		
		ungrp = new UnGroupCommand(idDaRimuovere, gruppi, idGroups);
		ungrp.doIt();
		
		idDaRimuovere = 1;
		
		ungrp = new UnGroupCommand(idDaRimuovere, gruppi, idGroups);
		ungrp.doIt();
		
		assertEquals(true, gruppi.isEmpty() && idGroups.getNextGrpId() == 1);
		
	}

	@Test
	public void ungrpUndoMulti() {//faccio più ungrp
		CircleObject c0 = new CircleObject(new Point(89,99), 30.0);
		c0.setID(0);
		gruppo.add(c0);
		
		CircleObject c1 = new CircleObject(new Point(200,200), 23.0);
		c1.setID(1);
		gruppo.add(c1);
		
		RectangleObject r = new RectangleObject(new Point(20,30), 5.0, 12.0);
		r.setID(2);
		gruppo.add(r);
		
		List<AbstractGraphicObject> gruppo1 = new LinkedList<>();
		gruppo1.add(c0);gruppo1.add(r);
		
		gruppi.put(idGroups.getNextGrpId(), gruppo);
		idGroups.incrementa();
		
		gruppi.put(idGroups.getNextGrpId(), gruppo1);
		idGroups.incrementa();
		
		idDaRimuovere = 0;
		
		ungrp = new UnGroupCommand(idDaRimuovere, gruppi, idGroups);
		ungrp.doIt();
		ungrp.undoIt();
		
		idDaRimuovere = 1;
		
		ungrp = new UnGroupCommand(idDaRimuovere, gruppi, idGroups);
		ungrp.doIt();
		ungrp.undoIt();
		
		assertEquals(true, gruppi.size() == 2 && idGroups.getNextGrpId() == 2);
	}

}
