package is.specificcommand;

import static org.junit.Assert.*;

import java.awt.geom.Point2D;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

import java.awt.Point;

import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.RectangleObject;
import is.shapes.view.GraphicObjectPanel;

public class MoveCommandTest {
	
	private Point2D oldPos;
	private Point2D newPos;
	
	private AbstractGraphicObject go;
	
	
	// se muoviamo un gruppo di oggetti
	private List<AbstractGraphicObject> listObj;
	private List<Point2D> listOldPos;
	 
	private GraphicObjectPanel gpanel;

	private MoveCommand mv;
	
	@Test
	public void mvDoObject() {//id oggetto		//listObj == null
		go = new CircleObject(new Point(25,25), 7.0);
		newPos = new Point(50,50);
		
		mv = new MoveCommand(go, newPos);
		mv.doIt();
		assertEquals(newPos, go.getPosition());	
	}
	
	@Test
	public void mvUndoObject() {//id oggetto		//listObj == null
		go = new CircleObject(new Point(25,25), 7.0);
		oldPos = go.getPosition();
		newPos = new Point(50,50);
		
		mv = new MoveCommand(go, newPos);
		mv.doIt();
		mv.undoIt();
		assertEquals(oldPos, go.getPosition());	
	}
	
	@Test
	public void mvDoGroup() {//id gruppo		//listObj != null
		gpanel = new GraphicObjectPanel();
		listObj = new LinkedList<>();
		listOldPos = new LinkedList<>();

		AbstractGraphicObject c0 = new CircleObject(new Point(25,25), 7.0);
		AbstractGraphicObject c1 = new CircleObject(new Point(40,70), 10.0);

		AbstractGraphicObject r = new RectangleObject(new Point(100,100), 15, 23);
		
		gpanel.add(c0); gpanel.add(c1); gpanel.add(r);

		listObj.add(c0); listObj.add(c1); listObj.add(r);
		
		listOldPos.add(c0.getPosition()); listOldPos.add(c1.getPosition()); listOldPos.add(r.getPosition());
		
		newPos = new Point(50,50);
		
		mv = new MoveCommand(listObj, newPos, gpanel);
		mv.doIt();
		assertEquals(newPos, r.getPosition());//ne basta solo uno degli oggetti

	}
	
	@Test
	public void mvUndoGroup() {//id gruppo		//listObj != null
		gpanel = new GraphicObjectPanel();
		listObj = new LinkedList<>();
		listOldPos = new LinkedList<>();

		AbstractGraphicObject c0 = new CircleObject(new Point(25,25), 7.0);
		AbstractGraphicObject c1 = new CircleObject(new Point(40,70), 10.0);

		AbstractGraphicObject r = new RectangleObject(new Point(100,100), 15, 23);
		
		gpanel.add(c0); gpanel.add(c1); gpanel.add(r);

		listObj.add(c0); listObj.add(c1); listObj.add(r);
		
		listOldPos.add(c0.getPosition()); listOldPos.add(c1.getPosition()); listOldPos.add(r.getPosition());
		
		newPos = new Point(50,50);
		
		mv = new MoveCommand(listObj, newPos, gpanel);
		mv.doIt();
		mv.undoIt();
		assertEquals(listOldPos.get(1), c1.getPosition());//ne basta solo uno degli oggetti

	}
	
	
	
	
	

}
