package is.specificcommand;

import static org.junit.Assert.*;

import java.awt.Point;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import is.interpreter.IdGroups;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.RectangleObject;
import is.shapes.view.GraphicObjectPanel;


public class DelCommandTest {
	
	private static AbstractGraphicObject go;
	private static GraphicObjectPanel gpanel;
	private static List<AbstractGraphicObject> listObj;
	private static Map<Integer, List<AbstractGraphicObject>> gruppi;
	private static IdGroups idGroups;
	
	private DelCommand del;
	
	@BeforeClass
	public static void init() {
		gpanel = new GraphicObjectPanel();
		idGroups = new IdGroups();
		
	}
	
	
	@Test
	public void delObj() {//del singolo oggetto => listObj == null
		go = new CircleObject(new Point(100,100), 30.0);
		go.setID(0);
		gpanel.add(go);
		del = new DelCommand(go, gpanel);
		del.doIt();
		assertFalse(gpanel.getList().contains(go));
	}
	
	@Test
	public void delGrp() {// in questo test inserisco elementi in gpanel ed in groups e con il delCommand li vado a togliere tutti 
							// mi aspetto quindi che sia gpanel che groups siano vuoti
		//del gruppo => listObj != null
		CircleObject c0 = new CircleObject(new Point(89,99), 30.0);
		c0.setID(0);
		gpanel.add(c0);
		
		CircleObject c1 = new CircleObject(new Point(200,200), 23.0);
		c1.setID(1);
		gpanel.add(c1);
		
		RectangleObject r = new RectangleObject(new Point(20,30), 5.0, 12.0);
		r.setID(2);
		gpanel.add(r);
		
		listObj = new LinkedList<>();
		listObj.add(c0); listObj.add(c1); listObj.add(r);
		gruppi = new HashMap<>();
		idGroups = new IdGroups();
		gruppi.put(idGroups.getNextGrpId(), listObj);
		idGroups.incrementa();;
		
		del = new DelCommand(listObj, gpanel, gruppi, idGroups, 0);
		del.doIt();
		
		verValiditaDoIt();
		
	}
	
	private void verValiditaDoIt() {
		assertEquals(true, gpanel.getList().isEmpty() && gruppi.isEmpty() && idGroups.getNextGrpId() == 0);
	}
	
	@Test
	public void undoDelObj() {
		go = new CircleObject(new Point(100,100), 30.0);
		go.setID(0);
		gpanel.add(go);
		del = new DelCommand(go, gpanel);
		del.doIt();
		del.undoIt();
		assertTrue(gpanel.getList().contains(go));
	}
	
	@Test
	public void undoDelGrp() {
		CircleObject c0 = new CircleObject(new Point(89,99), 30.0);
		c0.setID(0);
		gpanel.add(c0);
		
		CircleObject c1 = new CircleObject(new Point(200,200), 23.0);
		c1.setID(1);
		gpanel.add(c1);
		
		RectangleObject r = new RectangleObject(new Point(20,30), 5.0, 12.0);
		r.setID(2);
		gpanel.add(r);
		
		listObj = new LinkedList<>();
		listObj.add(c0); listObj.add(c1); listObj.add(r);
		gruppi = new HashMap<>();
		idGroups = new IdGroups();
		gruppi.put(idGroups.getNextGrpId(), listObj);
		idGroups.incrementa();;
		del = new DelCommand(listObj, gpanel, gruppi, idGroups, 0);
		del.doIt();
		del.undoIt();
		verValiditaUndoIt();
		
	}
	
	private void verValiditaUndoIt() {
		assertEquals(false, gpanel.getList().isEmpty() || gruppi.isEmpty() || idGroups.getNextGrpId() == 0);
	}

}
