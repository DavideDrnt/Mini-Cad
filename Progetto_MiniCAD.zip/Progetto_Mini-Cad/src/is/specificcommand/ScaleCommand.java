package is.specificcommand;

import java.util.List;

import is.command.Command;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;

public class ScaleCommand implements Command{
	
	private GraphicObjectPanel gpanel;
	private AbstractGraphicObject go;
	private List<AbstractGraphicObject> listObj;
	
	private double factor;
	
	public ScaleCommand(AbstractGraphicObject go, double factor) {
		this.go = go;
		this.factor = factor;
	}
	
	public ScaleCommand(List<AbstractGraphicObject> list, GraphicObjectPanel gpanel, double factor) {
		this.gpanel = gpanel;
		this.listObj = list;
		this.factor = factor;
	}

	@Override
	public boolean doIt() {
		if(listObj == null) {//ridimensionamento di un singolo oggetto
			go.scale(factor);
		}else {
			for(AbstractGraphicObject ago : listObj) {// gruppo di oggetti
				if(gpanel.getList().contains(ago)) {
					ago.scale(factor);
				}
			}
		}
		return true;
	}

	@Override
	public boolean undoIt() {
		if(listObj == null) {//undo singolo oggetto
			go.scale(1.0 / factor);
		}else {
			for(AbstractGraphicObject ago : listObj) {
				if(gpanel.getList().contains(ago)) {
					ago.scale(1.0 / factor);
				}
			}
		}
		return true;
	}

}
