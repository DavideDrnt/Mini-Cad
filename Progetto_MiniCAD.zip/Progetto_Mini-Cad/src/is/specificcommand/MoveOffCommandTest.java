package is.specificcommand;

import static org.junit.Assert.*;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.RectangleObject;
import is.shapes.view.GraphicObjectPanel;

public class MoveOffCommandTest {

	private Point2D oldPos;
	private Point2D newPos;
	
	private AbstractGraphicObject go;
	
	
	// se muoviamo un gruppo di oggetti
	private List<AbstractGraphicObject> listObj;
	private List<Point2D> listOldPos;
	 
	private GraphicObjectPanel gpanel;

	private MoveOffCommand mvoff;
	
	@Test
	public void mvoffDoObject() {//id oggetto		//listObj == null
		go = new CircleObject(new Point(25,25), 7.0);
		newPos = new Point(50,50);
		Point2D endPos = new Point2D.Double();
		endPos.setLocation(go.getPosition().getX() + newPos.getX(), go.getPosition().getY() + newPos.getY());
		mvoff = new MoveOffCommand(go, newPos);
		mvoff.doIt();
		assertEquals(endPos, go.getPosition());	
	}
	
	@Test
	public void mvoffUndoObject() {//id oggetto		//listObj == null
		go = new CircleObject(new Point(25,25), 7.0);
		oldPos = go.getPosition();
		newPos = new Point(50,50);
		
		mvoff = new MoveOffCommand(go, newPos);
		mvoff.doIt();
		mvoff.undoIt();
		assertEquals(oldPos, go.getPosition());	
	}
	
	@Test
	public void mvoffDoGroup() {//id gruppo		//listObj != null
		gpanel = new GraphicObjectPanel();
		listObj = new LinkedList<>();
		listOldPos = new LinkedList<>();

		AbstractGraphicObject c0 = new CircleObject(new Point(25,25), 7.0);
		AbstractGraphicObject c1 = new CircleObject(new Point(40,70), 10.0);
		
		LinkedList<Point2D> listEndPos = new LinkedList<>();
		
		AbstractGraphicObject r = new RectangleObject(new Point(100,100), 15, 23);
		
		gpanel.add(c0); gpanel.add(c1); gpanel.add(r);

		listObj.add(c0); listObj.add(c1); listObj.add(r);
		
		listOldPos.add(c0.getPosition()); listOldPos.add(c1.getPosition()); listOldPos.add(r.getPosition());
		
		newPos = new Point(50,50);
		
		popolaListEndPos(listEndPos);
		
		mvoff = new MoveOffCommand(listObj, newPos, gpanel);
		mvoff.doIt();

		assertEquals(true, verPos(listEndPos));

	}
	
	private void popolaListEndPos(List<Point2D> listEndPos) {
		for(Point2D p : listOldPos) {
			Point2D endPos = new Point2D.Double();
			endPos.setLocation(p.getX() + newPos.getX(), p.getY() + newPos.getY());
			listEndPos.add(endPos);
		}
	}
	
	private boolean verPos(List<Point2D> listEndPos) {
		
		for(int i=0; i < listEndPos.size(); i++) {
			if(!(listObj.get(i).getPosition().equals(listEndPos.get(i)))){
				return false;
			}
		}
		return true;
	}
	
	@Test
	public void mvoffUndoGroup() {//id gruppo		//listObj != null
		gpanel = new GraphicObjectPanel();
		listObj = new LinkedList<>();
		listOldPos = new LinkedList<>();

		AbstractGraphicObject c0 = new CircleObject(new Point(25,25), 7.0);
		AbstractGraphicObject c1 = new CircleObject(new Point(40,70), 10.0);

		AbstractGraphicObject r = new RectangleObject(new Point(100,100), 15, 23);
		
		gpanel.add(c0); gpanel.add(c1); gpanel.add(r);

		listObj.add(c0); listObj.add(c1); listObj.add(r);
		
		listOldPos.add(c0.getPosition()); listOldPos.add(c1.getPosition()); listOldPos.add(r.getPosition());
		
		newPos = new Point(50,50);
		
		mvoff = new MoveOffCommand(listObj, newPos, gpanel);
		mvoff.doIt();
		mvoff.undoIt();
		assertEquals(listOldPos.get(1), c1.getPosition());//ne basta solo uno degli oggetti

	}

}
