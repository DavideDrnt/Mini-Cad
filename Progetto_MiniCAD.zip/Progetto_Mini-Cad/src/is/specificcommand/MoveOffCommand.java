package is.specificcommand;

import java.awt.geom.Point2D;
import java.util.List;

import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.GraphicObject;
import is.shapes.view.GraphicObjectPanel;

public class MoveOffCommand extends MoveCommand{
	
	public MoveOffCommand(GraphicObject go, Point2D pos) {
		super(go, pos);
	}

	public MoveOffCommand(List<AbstractGraphicObject> list, Point2D pos, GraphicObjectPanel panel) {
		super(list, pos, panel);
	}
	
	@Override
	public boolean doIt() {
		Point2D endPos = new Point2D.Double();
		if(listObj == null) {//sposto un singolo oggetto e non un gruppo
			endPos.setLocation(oldPos.getX() + newPos.getX(), oldPos.getY() + newPos.getY());
			object.moveTo(endPos);
		}else { 
			for(int i=0; i<this.listObj.size(); i++) {
				Point2D pos = listOldPos.get(i);
				endPos.setLocation(pos.getX() + newPos.getX(), pos.getY() + newPos.getY());
				listObj.get(i).moveTo(endPos);
			}
		}
		
		return true;
	}
	
	@Override
	public boolean undoIt() {
		
		if(listObj == null) {
			object.moveTo(oldPos);
		}else {
			for(int i=0; i<listObj.size(); i++) {
				if(gpanel.getList().contains(listObj.get(i))) {
					listObj.get(i).moveTo(listOldPos.get(i));
				}
			}
		}
		return true;
	}
	

}
