package is.specificcommand;

import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import is.command.Command;
import is.interpreter.IdGroups;
import is.shapes.model.AbstractGraphicObject;

public class GroupCommand implements Command {
	
	private List<AbstractGraphicObject> gruppo;
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	
	private int id;
	private IdGroups idGroups;
	
	public GroupCommand(List<AbstractGraphicObject> gruppo, Map<Integer, List<AbstractGraphicObject>> gruppi, 
			IdGroups idG) {
		this.gruppo = gruppo;
		this.gruppi = gruppi;
		this.idGroups = idG;
	}

	@Override
	public boolean doIt() {
		if(gruppi.containsValue(gruppo)) {
			JOptionPane.showMessageDialog(null, "Gruppo già creato.");
		}else {
			gruppi.put(idGroups.getNextGrpId(), gruppo);
			id = idGroups.getNextGrpId();
			idGroups.incrementa();
			JOptionPane.showMessageDialog(null, "Gruppo gid_"+id+" creato.");
		}
		return true;
	}

	@Override
	public boolean undoIt() {
		if(gruppi.containsKey(id)) {
			gruppi.remove(id);
			idGroups.decrementa();
			JOptionPane.showMessageDialog(null, "Gruppo gid_"+id+" rimosso.");
		}
		return true;
	}
	
	public int getID() {return id;} 
	

}
