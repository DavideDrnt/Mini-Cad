package is.specificcommand;


import is.command.Command;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;

public class NewCommand implements Command{
	
	private AbstractGraphicObject go;
	private GraphicObjectPanel gpanel;
	
	
	
	public NewCommand(GraphicObjectPanel gpanel, AbstractGraphicObject go) {
		this.go = go;
		this.gpanel = gpanel;
	}
	
	
	

	@Override
	public boolean doIt() {
		gpanel.add(go);
		return true;
	}

	@Override
	public boolean undoIt() {
		gpanel.remove(go);
		
		return true;
	}
	
	

}
