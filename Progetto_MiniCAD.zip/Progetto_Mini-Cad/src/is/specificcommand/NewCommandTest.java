package is.specificcommand;

import static org.junit.Assert.*;

import java.awt.Point;

import org.junit.Test;

import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.RectangleObject;
import is.shapes.view.GraphicObjectPanel;

public class NewCommandTest {
	private static AbstractGraphicObject go;
	private static GraphicObjectPanel gpanel;
	
	private NewCommand create;
	
	
	@Test
	public void newDo() {
		gpanel = new GraphicObjectPanel();
		go = new CircleObject(new Point(30,30), 23.0);
		create = new NewCommand(gpanel, go);
		create.doIt();
		assertEquals(true, (gpanel.getList().contains(go)) && (gpanel.getList().size() == 1));
	}
	
	@Test
	public void newUndo() {
		gpanel = new GraphicObjectPanel();
		go = new CircleObject(new Point(30,30), 23.0);
		create = new NewCommand(gpanel, go);
		create.doIt();
		create.undoIt();
		assertEquals(true, !((gpanel.getList().contains(go)) || (gpanel.getList().size() >= 1)));
	}
	
	@Test
	public void newDoMulti() {
		gpanel = new GraphicObjectPanel();
		go = new CircleObject(new Point(30,30), 23.0);
		
		RectangleObject r = new RectangleObject(new Point(80,80), 23.0,14.0);
		
		create = new NewCommand(gpanel, go);
		create.doIt();
		
		create = new NewCommand(gpanel, r);
		create.doIt();
		
		assertEquals(true, (gpanel.getList().contains(go)) && (gpanel.getList().contains(r)) && (gpanel.getList().size() == 2));
	}
	
	@Test
	public void newUndoMulti() {
		gpanel = new GraphicObjectPanel();
		go = new CircleObject(new Point(30,30), 23.0);
		
		RectangleObject r = new RectangleObject(new Point(80,80), 23.0,14.0);
		
		create = new NewCommand(gpanel, go);
		create.doIt();
		create.undoIt();

		create = new NewCommand(gpanel, r);
		create.doIt();
		create.undoIt();
		
		assertEquals(true, !((gpanel.getList().contains(go)) || (gpanel.getList().contains(r)) || (gpanel.getList().size() >= 1)));
	}
	
	

}
