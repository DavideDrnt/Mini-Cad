package is.specificcommand;

import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import is.command.Command;
import is.interpreter.Opzioni;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.ImageObject;
import is.shapes.model.RectangleObject;
import is.shapes.view.GraphicObjectPanel;

public class ListCommand implements Command{
	
	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private int id;
	private Opzioni opt;
	private String type;
	
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	
	
	public ListCommand(GraphicObjectPanel gpanel, List<AbstractGraphicObject> list, int id, Opzioni opt, String type, Map<Integer, List<AbstractGraphicObject>> gruppi) {
		this.gpanel = gpanel;
		this.listObj= list;
		this.id = id;
		this.opt = opt;
		this.type = type;
		this.gruppi = gruppi;
		doIt();
	}
	
	

	@Override
	public boolean doIt() {
		String msg = "";
		switch(opt) {
		default: // id oggetto singolo
			if(listObj == null) {
				JOptionPane.showMessageDialog(new JTextArea(20,40), "Oggetto id_"+id+" non esiste.");

			}else {
				for(int i=0; i<listObj.size(); i++) {
					if(listObj.get(i).getID() == id && gpanel.getList().contains(listObj.get(i))) {
						msg += proprietaObj(listObj.get(i));
						break;
					}
				}
				if(!(msg.equals(""))) {
					showMessage(msg);
				}else {
					JOptionPane.showMessageDialog(new JTextArea(20,40), "Oggetto "+id+" non esiste.");
				}
			}
			break;
		case GRP:// id gruppo
			if(gruppi == null) {
				JOptionPane.showMessageDialog(new JTextArea(20,40), "Gruppo gid_"+id+" non esistente.");

			}else if(!gruppi.containsKey(id)){
				JOptionPane.showMessageDialog(new JTextArea(20,40), "Gruppo gid_"+id+" non esistente.");
			}else {
				msg += "Proprietà del gruppo gid_"+id+":\n";
				for(AbstractGraphicObject ago : listObj) {
					if(gruppi.get(id).contains(ago) && gpanel.getList().contains(ago)) {
						msg += proprietaObj(ago)+"\n";
					}
				}
				showMessage(msg);

				
			}
			break;
		case TYPE: // tipo
			if(listObj == null) {
				JOptionPane.showMessageDialog(new JTextArea(20,40), "Oggetti di tipo "+type+" non esistenti.");

			}else {
				msg ="Proprietà degli oggetti di tipo "+type+":\n";
				for(int i=0; i<listObj.size(); i++) {
					if(listObj.get(i).getType().equalsIgnoreCase(type) && gpanel.getList().contains(listObj.get(i))) {
						msg += proprietaTipo(listObj.get(i));
					}
				}
				showMessage(msg);

			}
			break;
		case ALL:// all
			if(listObj == null) {
				JOptionPane.showMessageDialog(new JTextArea(20,40), "Nessun oggetto esistente.");

			}else {
					msg += "Proprieta di tutti gli oggetti: \n";
					for(int i=0; i<listObj.size(); i++) {
						if(gpanel.getList().contains(listObj.get(i))) {
							msg += proprietaObj(listObj.get(i))+"\n";
						}
					}
					showMessage(msg);

			}
			break;
		case GROUPS:// groups
			if(gruppi == null) {
				JOptionPane.showMessageDialog(new JTextArea(20,40), "Nessun gruppo esistente.");

			}else {
				msg += "Proprietà di tutti i gruppi:\n";
				
				for(int i=0; i<gruppi.size(); i++) {
					msg += "Gruppo gid_"+i+":\n";
					
					for(AbstractGraphicObject ago : listObj) {
						if(gruppi.get(i).contains(ago) && gpanel.getList().contains(ago)) {
							msg += proprietaObj(ago)+"\n";
						}
					}
					msg +="\n";
				}
				showMessage(msg);

			}
			break;
		}
		return true;
	}

	@Override
	public boolean undoIt() {
		throw new UnsupportedOperationException();
	}
	
	private String proprietaObj(AbstractGraphicObject go) {
		String tipoObj = go.getType();
		String ret = "Proprietà oggetto id_"+go.getID()+": tipo= "+tipoObj;
		
		if(tipoObj.equalsIgnoreCase("circle")) {// raggio ; (x,y)
			CircleObject circle = (CircleObject) go;
			ret += " raggio = "+circle.getRadius()+" posizione = ("+circle.getPosition().getX()+", "+circle.getPosition().getY()+")";
		} else if(tipoObj.equalsIgnoreCase("rectangle")) {// altezza ; base ; (x,y)
			RectangleObject rectangle = (RectangleObject) go;
			ret += " altezza = "+rectangle.getDimension().getHeight()+" base = "+rectangle.getDimension().getWidth()+" posizione = ("+rectangle.getPosition().getX()+", "+rectangle.getPosition().getY()+")";
		}else if(tipoObj.equalsIgnoreCase("image")) {// path ; (x,y)
			ImageObject img = (ImageObject) go;
			ret += " path = "+img.getPath()+" posizione = ("+img.getPosition().getX()+", "+img.getPosition().getY()+")";
		}
		
		return ret;
	}
	
	private String proprietaTipo(AbstractGraphicObject go) {
		String tipoObj = go.getType();
		String ret = "Proprietà oggetto id_"+go.getID()+": ";
		
		if(tipoObj.equalsIgnoreCase("circle")) {// raggio ; (x,y)
			CircleObject circle = (CircleObject) go;
			ret += " raggio = "+circle.getRadius()+" posizione = ("+circle.getPosition().getX()+", "+circle.getPosition().getY()+")\n";
		} else if(tipoObj.equalsIgnoreCase("rectangle")) {// altezza ; base ; (x,y)
			RectangleObject rectangle = (RectangleObject) go;
			ret += " altezza = "+rectangle.getDimension().getHeight()+" base = "+rectangle.getDimension().getWidth()+" posizione = ("+rectangle.getPosition().getX()+", "+rectangle.getPosition().getY()+")\n";
		}else if(tipoObj.equalsIgnoreCase("image")) {// path ; (x,y)
			ImageObject img = (ImageObject) go;
			ret += " path = "+img.getPath()+" posizione = ("+img.getPosition().getX()+", "+img.getPosition().getY()+")\n";
		}
		
		return ret;
	}
	
	private void showMessage(String msg) {
		JTextArea textArea = new JTextArea(20,40);
		textArea.setText(msg);
		textArea.setEditable(false);
		JScrollPane scroll = new JScrollPane(textArea);
		JOptionPane.showMessageDialog(null, scroll);
	}

}
