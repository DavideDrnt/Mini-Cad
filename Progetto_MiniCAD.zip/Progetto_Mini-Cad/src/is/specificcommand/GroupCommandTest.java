package is.specificcommand;

import static org.junit.Assert.*;

import java.awt.Point;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import is.interpreter.IdGroups;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.RectangleObject;

public class GroupCommandTest {
	
	private static List<AbstractGraphicObject> gruppo;
	private static Map<Integer, List<AbstractGraphicObject>> gruppi;
	private static IdGroups idGroups;
	
	private GroupCommand grp;
	
	@Before
	public void reset() {
		gruppo = new LinkedList<>();
		gruppi = new HashMap<>();
		idGroups = new IdGroups();
		
	}
	
	
	@Test
	public void grpDoObjects() {
		CircleObject c0 = new CircleObject(new Point(89,99), 30.0);
		c0.setID(0);
		gruppo.add(c0);
		
		CircleObject c1 = new CircleObject(new Point(200,200), 23.0);
		c1.setID(1);
		gruppo.add(c1);
		
		RectangleObject r = new RectangleObject(new Point(20,30), 5.0, 12.0);
		r.setID(2);
		gruppo.add(r);
		
		
		grp = new GroupCommand(gruppo, gruppi, idGroups);
		grp.doIt();
		assertEquals(1, idGroups.getNextGrpId());
		
	}
	
	@Test
	public void grpUndoObjects() {
		CircleObject c0 = new CircleObject(new Point(89,99), 30.0);
		c0.setID(0);
		gruppo.add(c0);
		
		CircleObject c1 = new CircleObject(new Point(200,200), 23.0);
		c1.setID(1);
		gruppo.add(c1);
		
		RectangleObject r = new RectangleObject(new Point(20,30), 5.0, 12.0);
		r.setID(2);
		gruppo.add(r);
		
		grp = new GroupCommand(gruppo, gruppi, idGroups);
		grp.doIt();
		grp.undoIt();
		assertEquals(true, gruppi.isEmpty() && idGroups.getNextGrpId() == 0);
		
	}
	
	@Test
	public void grpDoMultiGroup() {//faccio più grp
		CircleObject c0 = new CircleObject(new Point(89,99), 30.0);
		c0.setID(0);
		gruppo.add(c0);
		
		CircleObject c1 = new CircleObject(new Point(200,200), 23.0);
		c1.setID(1);
		gruppo.add(c1);
		
		RectangleObject r = new RectangleObject(new Point(20,30), 5.0, 12.0);
		r.setID(2);
		gruppo.add(r);
		
		List<AbstractGraphicObject> gruppo1 = new LinkedList<>();
		gruppo1.add(c0);gruppo1.add(r);
		
		grp = new GroupCommand(gruppo, gruppi, idGroups);
		grp.doIt();
		grp = new GroupCommand(gruppo1, gruppi, idGroups);
		grp.doIt();
		assertEquals(true, gruppi.size() == 2 && idGroups.getNextGrpId() == 2);
		
	}
	
	@Test
	public void grpUndoMultiGroup() {//faccio più grp
		CircleObject c0 = new CircleObject(new Point(89,99), 30.0);
		c0.setID(0);
		gruppo.add(c0);
		
		CircleObject c1 = new CircleObject(new Point(200,200), 23.0);
		c1.setID(1);
		gruppo.add(c1);
		
		RectangleObject r = new RectangleObject(new Point(20,30), 5.0, 12.0);
		r.setID(2);
		gruppo.add(r);
		
		List<AbstractGraphicObject> gruppo1 = new LinkedList<>();
		gruppo1.add(c0);gruppo1.add(r);
		
		grp = new GroupCommand(gruppo, gruppi, idGroups);
		grp.doIt();
		grp.undoIt(); //groups.isEmpty() => true
		grp = new GroupCommand(gruppo1, gruppi, idGroups);
		grp.doIt();
		assertEquals(true, !(gruppi.containsValue(gruppo)) && (gruppi.get(0).equals(gruppo1)));
		
	}
	
	
	
	
	

}
