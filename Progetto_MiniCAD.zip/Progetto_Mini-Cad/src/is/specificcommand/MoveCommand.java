package is.specificcommand;

import java.awt.geom.Point2D;
import java.util.LinkedList;
import java.util.List;

import is.command.Command;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.GraphicObject;
import is.shapes.view.GraphicObjectPanel;

public class MoveCommand implements Command{
	
	protected Point2D oldPos;
	protected Point2D newPos;
	
	protected GraphicObject object;
	
	
	// se muoviamo un gruppo di oggetti
	protected List<AbstractGraphicObject> listObj;
	protected List<Point2D> listOldPos = new LinkedList<>();
	 
	protected GraphicObjectPanel gpanel;

	//singolo oggetto
	public MoveCommand(GraphicObject go, Point2D pos) {
		this.object = go;
		oldPos = go.getPosition();
		newPos = pos;
		
	}
	
	// gruppo 
	
	public MoveCommand(List<AbstractGraphicObject> list, Point2D pos, GraphicObjectPanel panel) {
		newPos = pos;
		this.listObj = list;
		this.gpanel = panel;
		for(AbstractGraphicObject ago : listObj) {
			if(gpanel.getList().contains(ago)) {
				this.listOldPos.add(ago.getPosition());
			}
		}
	}
	
	

	@Override
	public boolean doIt() {
		if(listObj == null) {//sposto un singolo oggetto e non un gruppo
			object.moveTo(newPos);
		}else {
			for(AbstractGraphicObject ago : listObj) {
				if(gpanel.getList().contains(ago)) {
					ago.moveTo(newPos);
				}
			}
		}
		
		return true;
	}

	@Override
	public boolean undoIt() {
		if(listObj == null) {
			object.moveTo(oldPos);
		}else {
			for(int i=0; i<this.listObj.size(); i++) {
				if(gpanel.getList().contains(listObj.get(i))) {
					listObj.get(i).moveTo(listOldPos.get(i));
				}
			}
		}
		return true;
	}

}
