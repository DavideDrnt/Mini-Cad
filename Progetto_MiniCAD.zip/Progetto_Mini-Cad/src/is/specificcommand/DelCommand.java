package is.specificcommand;

import java.util.List;
import java.util.Map;

import is.command.Command;
import is.interpreter.IdGroups;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;

public class DelCommand implements Command{
	
	private AbstractGraphicObject go;
	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	private IdGroups idGroups;
	
	private int idDaRimuovere;
	
	public DelCommand(AbstractGraphicObject go, GraphicObjectPanel gpanel) {
		this.go = go;
		this.gpanel = gpanel;

	}
	
	public DelCommand(List<AbstractGraphicObject> list, GraphicObjectPanel panel, Map<Integer, List<AbstractGraphicObject>> gruppi,
			IdGroups idGroups, int idDaRimuovere) {
		this.gpanel = panel;
		this.listObj = list;
		this.gruppi = gruppi;
		this.idGroups = idGroups;
		this.idDaRimuovere = idDaRimuovere;
	}

	@Override
	public boolean doIt() {
		if(listObj == null) {
			gpanel.remove(go);
		}else {
			for(AbstractGraphicObject ago : listObj) {
				if(gpanel.getList().contains(ago)) {
					gpanel.remove(ago);
				}
			}
			gruppi.remove(idDaRimuovere);
			if(idDaRimuovere == (idGroups.getNextGrpId() - 1)) {//id ultimo gruppo
				idGroups.decrementa();
			}
		}
		
		return true;
	}

	@Override
	public boolean undoIt() {
		if(listObj == null) {
			gpanel.add(go);
		}else {
			for(AbstractGraphicObject ago : listObj) {
				gpanel.add(ago);
			}
			gruppi.put(idDaRimuovere, listObj);
			if(idDaRimuovere == idGroups.getNextGrpId()) {//id ultimo gruppo
				idGroups.incrementa();;
			}
		}
		return true;
	}

}
