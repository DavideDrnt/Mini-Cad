package is.specificcommand;

import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import is.command.Command;
import is.interpreter.Opzioni;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.RectangleObject;
import is.shapes.view.GraphicObjectPanel;

public class PerimeterCommand implements Command{

	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	
	private int id;
	private Opzioni opt;
	private String type;
	
	
	public PerimeterCommand(List<AbstractGraphicObject> list, Map<Integer, List<AbstractGraphicObject>> gruppi, GraphicObjectPanel gpanel, int id, Opzioni opt, String type) {
		this.listObj = list;
		this.gruppi = gruppi;
		this.gpanel = gpanel;
		this.id = id;
		this.type = type;
		this.opt = opt;
		doIt();
	}
	

	@Override
	public boolean doIt() {
		double perimeter = 0.0;
		switch(opt) {
		default: // id singolo oggetto
			if(listObj == null) {
				JOptionPane.showMessageDialog(null, "Oggetto non presente.");
			}else{
				for(AbstractGraphicObject ago : listObj) {
					if(ago.getID() == id && gpanel.getList().contains(ago)) {
						perimeter = calcolaPerimeterObj(ago);
						break;
					}
				}
				if(perimeter != 0.0) {
					JOptionPane.showMessageDialog(null, "Perimetro oggetto id_"+id+" = "+perimeter);
				}else {
					JOptionPane.showMessageDialog(null, "Oggetto non presente.");

				}
			}
			break;
		case GRP: // gruppo di oggetti
			if(gruppi == null) {
				JOptionPane.showMessageDialog(null, "Gruppo non presente.");
			}else {
				for(AbstractGraphicObject ago : listObj) {
					if(gruppi.get(id).contains(ago) && gpanel.getList().contains(ago)) {
						perimeter += calcolaPerimeterObj(ago);
					}
				}
				if(perimeter != 0.0) {
					JOptionPane.showMessageDialog(null, "Perimetro gruppo gid_"+id+" = "+perimeter);
				}else {
					JOptionPane.showMessageDialog(null, "Gruppo non presente.");

				}
			}
			break;
		case TYPE: // tipo specifico
			if(listObj == null) {
				JOptionPane.showMessageDialog(null, "Oggetti di tipo "+type+" non presenti.");
			}else {
				for(AbstractGraphicObject ago : listObj) {
					if(ago.getType().equalsIgnoreCase(type) && gpanel.getList().contains(ago)) {
						perimeter += calcolaPerimeterObj(ago);
					}
				}
				if(perimeter != 0.0) {
					JOptionPane.showMessageDialog(null, "Perimetro oggetti di tipo "+type+" = "+perimeter);
				}else {
					JOptionPane.showMessageDialog(null, "Oggetti di tipo "+type+" non presenti.");

				}
			}
			break;
		case ALL:// all
			if(listObj == null) {
				JOptionPane.showMessageDialog(null, "Oggetti non presenti.");
			}else {
				for(AbstractGraphicObject ago : listObj) {
					if(gpanel.getList().contains(ago)) {
						perimeter += calcolaPerimeterObj(ago);
					}
				}
				if(perimeter != 0.0) {
					JOptionPane.showMessageDialog(null, "Perimetro totale oggetti = "+perimeter);
				}else {
					JOptionPane.showMessageDialog(null, "Oggetti non presenti.");

				}
			}
			break;
		}
		return true;
	}

	@Override
	public boolean undoIt() {
		throw new UnsupportedOperationException();
	}
	
	private double calcolaPerimeterObj(AbstractGraphicObject ago) {
		double ret = 0.0;
		String tipoObj = ago.getType();
		if(tipoObj.equalsIgnoreCase("circle")) {
			CircleObject circle = (CircleObject) ago;
			ret = circle.perimeter();
		}else if(tipoObj.equalsIgnoreCase("rectangle")) {
			RectangleObject rect = (RectangleObject) ago;
			ret = rect.perimeter();
		}
		
		return ret;
		
	}


}
