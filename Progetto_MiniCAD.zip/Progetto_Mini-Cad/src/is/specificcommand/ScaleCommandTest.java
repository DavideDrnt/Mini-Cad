package is.specificcommand;

import static org.junit.Assert.*;

import java.awt.Point;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.RectangleObject;
import is.shapes.view.GraphicObjectPanel;

public class ScaleCommandTest {
	
	private GraphicObjectPanel gpanel;
	private AbstractGraphicObject go;
	private List<AbstractGraphicObject> listObj;
	
	private double factor;
	
	private ScaleCommand scale;
	
	
	@Test
	public void scaleDo() {//id oggetto
		go = new CircleObject(new Point(40,40), 23.0);
		factor = 2.0;
		
		CircleObject c = new CircleObject(new Point(40,40), 23.0);
		c.scale(factor);
		
		scale = new ScaleCommand(go, factor);
		scale.doIt();
		
		assertEquals(c.getDimension(), go.getDimension());
		
	}
	
	@Test
	public void scaleUndo() {//id oggetto
		go = new RectangleObject(new Point(40,40), 10.0, 20.0);
		factor = 2.0;
		
		RectangleObject r = new RectangleObject(new Point(40,40), 10.0, 20.0);
		
		
		scale = new ScaleCommand(go, factor);
		scale.doIt();
		scale.undoIt();
		
		assertEquals(r.getDimension(), go.getDimension());
		
	}
	
	@Test
	public void scaleDoGroup() {//id gruppo
		gpanel = new GraphicObjectPanel();
		listObj = new LinkedList<>();
		
		RectangleObject r0 = new RectangleObject(new Point(40,40), 10.0, 20.0);
		RectangleObject r1 = new RectangleObject(new Point(15,15), 20.0, 30.0);
		
		factor = 2.0;
		
		listObj.add(r0); listObj.add(r1);
		gpanel.add(r0); gpanel.add(r1); 
		
		LinkedList<AbstractGraphicObject> verList = new LinkedList<>();
		RectangleObject ver0 = new RectangleObject(new Point(40,40), 10.0, 20.0);
		RectangleObject ver1 = new RectangleObject(new Point(15,15), 20.0, 30.0);
		
		ver0.scale(factor);ver1.scale(factor);
		verList.add(ver0); verList.add(ver1);
		
		scale = new ScaleCommand(listObj, gpanel, factor);
		scale.doIt();
		
		assertEquals(true, verScale(verList));	
	}
	
	private boolean verScale(List<AbstractGraphicObject> verList) {
		for(int i=0; i<listObj.size(); i++) {
			if(!(listObj.get(i).getDimension().equals(verList.get(i).getDimension()))) {
				return false;
			}
		
		}
		return true;
	}
	
	@Test
	public void scaleUndoGroup() {//id gruppo
		gpanel = new GraphicObjectPanel();
		listObj = new LinkedList<>();
		
		RectangleObject r0 = new RectangleObject(new Point(40,40), 10.0, 20.0);
		RectangleObject r1 = new RectangleObject(new Point(15,15), 20.0, 30.0);
		
		factor = 2.0;
		
		listObj.add(r0); listObj.add(r1);
		gpanel.add(r0); gpanel.add(r1); 
		
		LinkedList<AbstractGraphicObject> verList = new LinkedList<>();
		RectangleObject ver0 = new RectangleObject(new Point(40,40), 10.0, 20.0);
		RectangleObject ver1 = new RectangleObject(new Point(15,15), 20.0, 30.0);
		
		verList.add(ver0); verList.add(ver1);
		
		scale = new ScaleCommand(listObj, gpanel, factor);
		scale.doIt();
		scale.undoIt();
		assertEquals(true, verScale(verList));	
	}
	
	
	
	
	
	
}
