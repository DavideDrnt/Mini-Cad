package is.interpreter;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import is.command.CommandHandler;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;
import is.specificcommand.GroupCommand;

public class Group extends Cmd{
	
	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	private IdGroups idGroups;
	private CommandHandler handler;
	
	private ListID listID;
	private StringTokenizer st;
	
	public Group (GraphicObjectPanel gpanel, 
			List<AbstractGraphicObject> listObj, Map<Integer, List<AbstractGraphicObject>> gruppi,
			IdGroups idGroups, CommandHandler handler, ListID listID) {
		this.listObj = listObj;
		this.gpanel = gpanel;
		this.gruppi = gruppi;
		this.idGroups = idGroups;
		this.handler = handler;
		this.listID = listID;
	}
	
	@Override
	public void interpreta(String comando) {
		try {
			st = new StringTokenizer(comando, " (),");
			st.nextToken();
			LinkedList<AbstractGraphicObject> ris = new LinkedList<>();
			listID.interpreta(comando);
			List<ObjID> lsObj =listID.getList();
			for(ObjID objID : lsObj) {
				if(objID.gerPrefix().equalsIgnoreCase("gid")) {
					List<AbstractGraphicObject> gruppoInGrp = gruppi.get(objID.getId());
					for(AbstractGraphicObject ago : gruppoInGrp) {
						ris.add(ago);
					}
				}else {
					int id = objID.getId();
					if(gpanel.getList().contains(listObj.get(id)) && !ris.contains(listObj.get(id))) {
						ris.add(listObj.get(id));
					}else {
						throw new Exception();
					}
				}
			}
			GroupCommand grp = new GroupCommand(ris, gruppi, idGroups);
			handler.handle(grp);
			
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null,  "Comando grp non corretto");
		}
	}
	

}
