package is.interpreter;

import java.io.Reader;

import is.command.CommandHandler;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;
public class ParserCmd {
	
	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private CommandHandler handler;
	
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	private IdGroups idGroups;
	
	private AnalizzatoreLessicale al;
	private Simboli simbolo;
	private Cmd comando;
	

	public ParserCmd(GraphicObjectPanel gpanel, 
			List<AbstractGraphicObject> listObj, Map<Integer, List<AbstractGraphicObject>> gruppi,
			IdGroups idGroups, CommandHandler handler, Reader in) {
		
		this.gpanel = gpanel;
		this.listObj = listObj;
		this.gruppi = gruppi;
		this.idGroups = idGroups;
		this.handler = handler;
		
		al = new AnalizzatoreLessicale(in);
		comando = cmd();
		simbolo = al.prossimoSimbolo();
	
	}
	
	private Cmd cmd() {
		Cmd ret = null;
		ObjID id = null;
		ListID listId = null;
		TypeConstr typeC = null;
		Pos position = null;
		Type typeCRI = null; 
		simbolo = al.prossimoSimbolo();
		switch(simbolo) {
		case NEW:
			typeC = tConstr();
			if(typeC == null) {
				JOptionPane.showMessageDialog(null, "Atteso \"circle\", \"rectangle\" o \"img\" dopo il comando new.");
				
				throw new SyntaxException("Atteso \"circle\", \"rectangle\" o \"img\" dopo il comando new.");
			}
			position = pos();
			ret = new Create(gpanel, listObj, handler, typeC, position);
			break;
			
		case DEL:
			simbolo = al.prossimoSimbolo();
			id = objId();
			ret =  new Remove(gpanel, listObj, gruppi, idGroups, handler, id);
			break;
			
		case MV:
			simbolo = al.prossimoSimbolo();
			id = objId();
			position = pos();
			ret = new Move(gpanel, listObj, gruppi, handler, id, position, false);
			break;
			
		case MVOFF:
			simbolo = al.prossimoSimbolo();
			id = objId();
			position = pos();
			ret = new Move(gpanel, listObj, gruppi, handler, id, position, true);
			break;
			
		case SCALE:
			simbolo = al.prossimoSimbolo();
			id = objId();
			PosFloat factor = posFloat();
			ret = new Scale(gpanel, listObj, gruppi, handler, id, factor);
			break;
			
		case LS:
			simbolo = al.prossimoSimbolo();
			if(simbolo == Simboli.CIRCLE || simbolo == Simboli.RECTANGLE || simbolo == Simboli.IMG) {
				typeCRI = type();
				ret = new LsType(gpanel, listObj, gruppi, handler, typeCRI);
			}else if(simbolo == Simboli.ALL) {
				ret = new LsAll(gpanel, listObj, gruppi);
			}else if(simbolo == Simboli.GROUPS) {
				ret = new LsGroups(gpanel, listObj, gruppi);
			}else {
				id = objId();
				ret = new LsObj(gpanel, listObj, gruppi, id);
			}
			break;
			
		case GRP:
			simbolo = al.prossimoSimbolo();
			listId = listID();
			ret = new Group(gpanel, listObj, gruppi, idGroups, handler, listId);
			
			break;
			
		case UNGRP:
			simbolo = al.prossimoSimbolo();
			id = objId();
			if(simbolo == Simboli.ID) {
				JOptionPane.showMessageDialog(null, "Comando errato: ungrp non può essere seguito dall'id di un oggetto ma solo da un gruppo di oggetti.");
				throw new SyntaxException("Comando errato: ungrp non può essere seguito dall'id di un oggetto ma solo da un gruppo di oggetti.");
				
			}else {
				ret = new Ungroup(gruppi, idGroups, handler, id);
			}
			break;
			
		case AREA:
			simbolo = al.prossimoSimbolo();
			if(simbolo == Simboli.CIRCLE || simbolo == Simboli.RECTANGLE) {
				typeCRI = type();
				ret = new AreaType(gpanel, listObj, gruppi, typeCRI);
				
			}else if(simbolo == Simboli.IMG) {
				JOptionPane.showMessageDialog(null, "Comando errato: area non può essere seguito da img.");
				throw new SyntaxException("Comando errato: area non può essere seguito da img.");
				
			}else if(simbolo == Simboli.ALL) {
				ret = new AreaAll(gpanel, listObj, gruppi);
			}else {
				id = objId();
				ret = new AreaObj(gpanel, listObj, gruppi, id);
				
			}
			break;
			
		case PERIMETER:
			simbolo = al.prossimoSimbolo();
			if(simbolo == Simboli.CIRCLE || simbolo == Simboli.RECTANGLE) {
				typeCRI = type();
				ret = new PerimeterType(gpanel, listObj, gruppi, typeCRI);
				
			}else if(simbolo == Simboli.IMG) {
				JOptionPane.showMessageDialog(null, "Comando errato: perimeter non può essere seguito da img.");
				throw new SyntaxException("Comando errato: perimeter non può essere seguito da img.");
				
			}else if(simbolo == Simboli.ALL) {
				ret = new PerimeterAll(gpanel, listObj, gruppi);
			}else {
				id = objId();
				ret = new PerimeterObj(gpanel, listObj, gruppi, id);
			
			}
			break;

		default:
			JOptionPane.showMessageDialog(null, "Comando errato");
			throw new SyntaxException("Comando errato");
		}
		
		return ret;
	}
	
	private TypeConstr tConstr() {
		
		simbolo = al.prossimoSimbolo();
		if(simbolo == Simboli.CIRCLE) {
			simbolo = al.prossimoSimbolo();
			if(simbolo == Simboli.TONDA_APERTA) {
				PosFloat raggio = posFloat();
				simbolo = al.prossimoSimbolo();
				if(simbolo == Simboli.TONDA_CHIUSA) {
					TypeConstr ret = new TypeConstr(raggio);
					return ret;
				}else {
					JOptionPane.showMessageDialog(null, "Attesa tonda chiusa dopo il valore del raggio");
					
					throw new SyntaxException("Attesa tonda chiusa dopo il valore del raggio");

				}
			}else {
				JOptionPane.showMessageDialog(null, "Attesa tonda aperta dopo 'circle' e prima del raggio");

				throw new SyntaxException("Attesa tonda aperta dopo 'circle' e prima del raggio");

			}
			
		}else if(simbolo == Simboli.RECTANGLE) {
			Pos dimensioni = pos();
			TypeConstr ret = new TypeConstr(dimensioni);
			return ret;
			
		}else if (simbolo == Simboli.IMG) {
			simbolo = al.prossimoSimbolo();
			if(simbolo == Simboli.TONDA_APERTA) {
				Path percorso = path();
				if(simbolo == Simboli.TONDA_CHIUSA) {
					TypeConstr ret = new TypeConstr(percorso);
					return ret;
				}else {
					JOptionPane.showMessageDialog(null, "Attesa tonda chiusa dopo il percorso");
					
					throw new SyntaxException("Attesa tonda chiusa dopo il percorso");

				}
			}else {
				JOptionPane.showMessageDialog(null, "Attesa tonda aperta prima del percorso");
				
				throw new SyntaxException("Attesa tonda aperta prima del percorso");

			}
		}
		
		return null;
	}
	
	private Pos pos() {
		Pos ret = null;
		simbolo = al.prossimoSimbolo();
		if(simbolo == Simboli.TONDA_APERTA) {
			PosFloat x = posFloat();
			simbolo = al.prossimoSimbolo();
			atteso(Simboli.VIRGOLA);
			PosFloat y = posFloat();
			simbolo = al.prossimoSimbolo();
			atteso(Simboli.TONDA_CHIUSA);
			ret = new Pos(x, y);
		}else {
			JOptionPane.showMessageDialog(null, "Attesa tonda aperta prima di inserire le coordinate. Es: (x,y)");

			throw new SyntaxException("Attesa tonda aperta prima di inserire coordinate");
		}
		
		return ret;
	}
	
	private ListID listID() {
		ObjID id = objId();
		ListID ret = new ListID(id);
		simbolo = al.prossimoSimbolo();
		while(simbolo == Simboli.VIRGOLA) {
			simbolo = al.prossimoSimbolo();
			ret.addObjID(objId());
			simbolo = al.prossimoSimbolo();
		}
		return ret;
	}
	
	private Type type() {
		Type ret = new Type();
		return ret;
	}
	
	private ObjID objId() {
		ObjID ret = null;
		if(simbolo == Simboli.ID || simbolo == Simboli.G_ID) {
			ret = new ObjID();
		}else {
			JOptionPane.showMessageDialog(null, "Atteso id di un oggetto o gruppo di oggetti in <objID>. Es: id_0 oppure gid_0");

			throw new SyntaxException("Atteso id di un oggetto o gruppo di oggetti in objId()");
		}
		return ret;
	}
	
	private PosFloat posFloat() {
		PosFloat ret = null;
		simbolo = al.prossimoSimbolo();
		
		if(simbolo == Simboli.POS_FLOAT) {
			ret = new PosFloat();
		}else {
			JOptionPane.showMessageDialog(null, "Atteso un floating point NON NEGATIVO in <posFloat>. Es: 23.0");

			throw new SyntaxException("Atteso un floating point NON NEGATIVO in posFloat()");
		}
		return ret;
	}
	
	private Path path() {
		Path ret = null;
		simbolo = al.prossimoSimbolo();
		ret = new Path();
		simbolo = al.prossimoSimbolo();
		
		return ret;
	}
	
	
	private void atteso(Simboli s) {
		if(simbolo != s) {
			String msg = " trovato "+simbolo+" mentre si attendeva "+s;
			throw new SyntaxException(msg);
		}
	}
	
	public Cmd getComando() {return comando;}
	
	

}
