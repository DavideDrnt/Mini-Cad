package is.interpreter;



import static org.junit.Assert.*;

import java.io.StringReader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import is.command.CommandHandler;
import is.command.HistoryCommandHandler;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;


public class ParserCmdTest{
	private static GraphicObjectPanel gpanel;
	private static List<AbstractGraphicObject> listObj;
	private static Map<Integer, List<AbstractGraphicObject>> gruppi;
	private static IdGroups idGroups;
	private static CommandHandler handler;
	
	private StringReader in;
	
	@BeforeClass
	public static void creaScenario() {
		gpanel = new GraphicObjectPanel();
		listObj = new LinkedList<>();
		gruppi = new HashMap<>();
		idGroups = new IdGroups();
		handler = new HistoryCommandHandler();
	}
	
////////	CREATE	////////
	
	@Test(expected = SyntaxException.class)
	public void newErrata() {//tipo inesistente
		in = new StringReader("new triangle (8.9) (100.0,100.0)");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test(expected = SyntaxException.class)
	public void newIncompleta() {//comando incompleto
		in = new StringReader("new");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test
	public void newCorretta() {
		in = new StringReader("new circle (8.9) (100.0,100.0)");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Create.class);
	}
	
	
	
	@Test
	public void newCircleCorretta() {
		in = new StringReader("new circle (8.9) (100.0,100.0)");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Create.class);
		
	}
	
	@Test(expected = SyntaxException.class)
	public void newCircleErrata() {//coordinate al posto del raggio
		in = new StringReader("new circle (8.9,20.0) (100.0,100.0)");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	
	
	@Test
	public void newRectangleCorretta() {
		in = new StringReader("new rectangle (8.9,10.0) (100.0,100.0)");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Create.class);
	}
	
	@Test(expected = SyntaxException.class)
	public void newRectangleErrata() {//un solo lato al posto di due
		in = new StringReader("new rectangle (8.9) (100.0,100.0)");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	
	
	@Test
	public void newImgCorretta() {
		in = new StringReader("new img (\"C:\\Users\\Davide\\Desktop\\Screenshot.png\") (100.0,100.0)");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Create.class);
	}
	
	@Test(expected = SyntaxException.class)
	public void newImageErrata() {//coordinate al posto del path
		in = new StringReader("new img (8.9,20.0) (100.0,100.0)");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	
	
//////	REMOVE	\\\\\\
	
	@Test(expected = SyntaxException.class)
	public void delErrata() {//tipo al posto di un id di gruppo o di oggetto
		in = new StringReader("del type");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test(expected = SyntaxException.class)
	public void delIncompleta() {//comando incompleto
		in = new StringReader("del");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test
	public void delCorrettaObj() {
		in = new StringReader("del id_0");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Remove.class);
	}
	
	@Test
	public void delCorrettaGroup() {
		in = new StringReader("del gid_0");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Remove.class);
	}
	
	
	
//////	MV e MVOFF	\\\\\\\
	
	@Test(expected = SyntaxException.class)
	public void moveErrata() {//tipo al posto di un id di oggetto o gruppo
		in = new StringReader("mv type");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test(expected = SyntaxException.class)
	public void moveIncompleta() {//comando incompleto
		in = new StringReader("mv");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test
	public void moveCorrettaObj() {
		in = new StringReader("mv id_0 (100.0,100.0)");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Move.class);
	}
	
	@Test
	public void moveCorrettaGroup() {
		in = new StringReader("mv gid_0 (100.0,100.0)");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Move.class);
	}
	
	@Test(expected = SyntaxException.class)
	public void moveOffErrata() {//tipo al posto di un id di oggetto o gruppo
		in = new StringReader("mvoff type");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test(expected = SyntaxException.class)
	public void moveOffIncompleta() {//comando incompleto
		in = new StringReader("mvoff");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test
	public void moveOffCorrettaObj() {
		in = new StringReader("mvoff id_0 (100.0,100.0)");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Move.class);
	}
	
	@Test
	public void moveOffCorrettaGroup() {
		in = new StringReader("mvoff gid_0 (100.0,100.0)");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Move.class);
	}
	
	
	
//////	SCALE	///////
	
	
	@Test(expected = SyntaxException.class)
	public void scaleErrata() {// presenza di parentesi tonde prima e dopo il fattore di scala
		in = new StringReader("scale id_0 (2.0)");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test(expected = SyntaxException.class)
	public void scaleIncompleta() {//comando incompleto
		in = new StringReader("scale");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test
	public void scaleCorrettaObj() {
		in = new StringReader("scale id_0 2.0");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Scale.class);
	}
	
	@Test
	public void scaleCorrettaGroup() {
		in = new StringReader("scale gid_0 2.0");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Scale.class);
	}
	
	
	
///////	GRP ed UNGRP	////////
	
	
	@Test(expected = SyntaxException.class)
	public void grpErrata() {// double a posto di una lista di id di oggetti e/o di gruppi
		in = new StringReader("grp 2.0");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test(expected = SyntaxException.class)
	public void grpIncompleta() {//comando incompleto
		in = new StringReader("grp");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test
	public void grpCorretta() {
		in = new StringReader("grp id_0,id_1");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Group.class);
	}
	
	@Test(expected = SyntaxException.class)
	public void ungrpErrata() {// tipo al posto di un id di un oggetto al posto di un id di un gruppo
		in = new StringReader("ungrp circle");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test(expected = SyntaxException.class)
	public void ungrpIncompleta() {//comando incompleto
		in = new StringReader("ungrp");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test
	public void ungrpCorretta() {
		in = new StringReader("ungrp gid_0");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), Ungroup.class);
	}
	

///////	LS	///////
	
	@Test(expected = SyntaxException.class)
	public void lsErrata() {// coordinate al posto di un id di un oggetto o di un gruppo 
		in = new StringReader("ls (89.0,99.0)");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test(expected = SyntaxException.class)
	public void lsIncompleta() {//comando incompleto
		in = new StringReader("ls");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test
	public void lsCorrettaObj() {// vale per un id di oggetto o di un gruppo
		in = new StringReader("ls gid_0");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), LsObj.class);
	}
	
	@Test
	public void lsCorrettaGroups() {
		in = new StringReader("ls groups");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), LsGroups.class);
	}
	
	@Test
	public void lsCorrettaType() {//vale anche per rectangle ed img
		in = new StringReader("ls circle");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), LsType.class);
	}
	
	@Test
	public void lsCorrettaAll() {
		in = new StringReader("ls all");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), LsAll.class);
	}
	
	

////// AREA	///////
	
	
	@Test(expected = SyntaxException.class)
	public void areaErrata() {// coordinate al posto di un id di un oggetto o di un gruppo 
		in = new StringReader("area (89.0,99.0)");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test(expected = SyntaxException.class)
	public void areaIncompleta() {//comando incompleto
		in = new StringReader("area");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test
	public void areaCorrettaObj() {// vale per un id di oggetto o di un gruppo
		in = new StringReader("area id_0");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), AreaObj.class);
	}
	
	@Test
	public void areaCorrettaType() {//vale anche per circle
		in = new StringReader("area rectangle");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), AreaType.class);
	}
	
	@Test
	public void areaCorrettaAll() {
		in = new StringReader("area all");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), AreaAll.class);
	}
	

/////	PERIMETER	/////
	
	@Test(expected = SyntaxException.class)
	public void perimeterErrata() {// passo come tipo img al posto di circle o di rectangle
		in = new StringReader("perimeter img");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test(expected = SyntaxException.class)
	public void perimeterIncompleta() {//comando incompleto
		in = new StringReader("perimeter");
		new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
	}
	
	@Test
	public void perimeterCorrettaObj() {// vale per un id di oggetto o di un gruppo
		in = new StringReader("perimeter gid_0");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), PerimeterObj.class);
	}
	
	@Test
	public void perimeterCorrettaType() {//vale anche per circle
		in = new StringReader("perimeter rectangle");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), PerimeterType.class);
	}
	
	@Test
	public void perimeterCorrettaAll() {
		in = new StringReader("perimeter all");
		ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
		assertEquals(parser.getComando().getClass(), PerimeterAll.class);
	}
	

}
