package is.interpreter;

public abstract class Ls extends Cmd{

}
