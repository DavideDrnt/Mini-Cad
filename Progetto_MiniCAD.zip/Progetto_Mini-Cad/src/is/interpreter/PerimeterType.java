package is.interpreter;

import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;
import is.specificcommand.PerimeterCommand;

public class PerimeterType extends Perimeter {

	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	
	private Type type;
	private StringTokenizer st;
	
	public PerimeterType (GraphicObjectPanel gpanel, 
			List<AbstractGraphicObject> listObj, Map<Integer, List<AbstractGraphicObject>> gruppi,
			Type type) {
		this.listObj = listObj;
		this.gpanel = gpanel;
		this.gruppi = gruppi;
		this.type = type;
	}
	
	@Override
	public void interpreta(String comando) {
		st = new StringTokenizer(comando, " (),");
		st.nextToken();
		type.interpreta(st.nextToken());
		String tipo = type.getType();
		Opzioni opt = Opzioni.TYPE;
		new PerimeterCommand(listObj, gruppi, gpanel, -1, opt, tipo);
	}
}
