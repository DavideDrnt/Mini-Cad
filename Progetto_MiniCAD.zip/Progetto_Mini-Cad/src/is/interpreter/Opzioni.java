package is.interpreter;

public enum Opzioni {
	SINGLE_OBJECT, GRP, ALL, GROUPS, TYPE;
}
