package is.interpreter;

public class Path implements Interpreter{
	private String percorso;
	@Override
	public void interpreta(String comando) {
		percorso = comando;
		
	}
	
	public String getPercorso() {return percorso;}

}
