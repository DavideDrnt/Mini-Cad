package is.interpreter;

import is.command.CommandHandler;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.ImageObject;
import is.shapes.model.RectangleObject;
import is.shapes.view.GraphicObjectPanel;
import is.specificcommand.NewCommand;

import java.awt.Image;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Create extends Cmd{
	private AbstractGraphicObject ago;
	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private CommandHandler handler;
	
	private TypeConstr typeC;
	private Pos position;
	private StringTokenizer st;
	
	
	public Create (GraphicObjectPanel gpanel, 
			List<AbstractGraphicObject> listObj, CommandHandler handler, 
			TypeConstr typeC, Pos position) {
		this.listObj = listObj;
		this.gpanel = gpanel;
		this.handler = handler;
		this.typeC = typeC;
		this.position = position;
	}
	
	@Override
	public void interpreta(String comando) {
		st = new StringTokenizer(comando, " \"(),");
		st.nextToken();
		try {
			typeC.interpreta(comando);//passo il comando intero
			String tipoObj = typeC.getType();
			st.nextToken();//tipo dell'oggetto da creare
			if(tipoObj.equalsIgnoreCase("circle")) {
				st.nextToken();//posfloat completo

				String cmdPos = ""+st.nextToken()+","+st.nextToken();//posfloat,posfloat
				
				position.interpreta(cmdPos);
				
				PosFloat raggio = typeC.getRaggio();
				Point2D coordinate = position.getPos();
				ago = new CircleObject(coordinate, raggio.getPos());
			
			}else if(tipoObj.equalsIgnoreCase("rectangle")) {
				
				st.nextToken();
				st.nextToken();
				
				String cmdPos = ""+st.nextToken()+","+st.nextToken();//posfloat,posfloat
				
				position.interpreta(cmdPos);
				
				Pos dimensioni = typeC.getDimensioni();
				Point2D coordinate = position.getPos();
				ago = new RectangleObject(coordinate, dimensioni.getPos().getX(), dimensioni.getPos().getY());
			}else if(tipoObj.equalsIgnoreCase("img")) {
				st.nextToken();//path
				
				
				String cmdPos = ""+st.nextToken()+","+st.nextToken();//posfloat,posfloat
				
				position.interpreta(cmdPos);
				Path percorso = typeC.getPercorso();
				String path = percorso.getPercorso();
				verPathImg(path);
				ImageIcon image = new ImageIcon(path);
				image.setDescription(path);
					
				Point2D coordinate = position.getPos();
				ago = new ImageObject(image, coordinate);
			}
			
			handler.handle(new NewCommand(gpanel, ago));
			gpanel.repaint();
			listObj.add(ago);
			ago.setID(listObj.indexOf(ago));
			
		}catch(IllegalArgumentException iae) {
			JOptionPane.showMessageDialog(null,  "Comando per creare errato");
		}
	}
	
	private void verPathImg(String path){
		try {
			@SuppressWarnings("unused")
			Image img = ImageIO.read(new File(path));
		}catch(IOException ioe) {
			throw new IllegalArgumentException();
		}
	}

}
