package is.interpreter;

public class PosFloat implements Interpreter{
	private double cord;
	
	@Override
	public void interpreta(String comando) {
		cord = Double.parseDouble(comando);
		
	}
	
	public double getPos() {return cord;}

}
