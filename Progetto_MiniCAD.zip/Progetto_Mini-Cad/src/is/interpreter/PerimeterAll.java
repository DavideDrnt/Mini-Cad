package is.interpreter;

import java.util.List;
import java.util.Map;

import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;
import is.specificcommand.PerimeterCommand;

public class PerimeterAll extends Perimeter{
	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	

	
	public PerimeterAll (GraphicObjectPanel gpanel, 
			List<AbstractGraphicObject> listObj, Map<Integer, List<AbstractGraphicObject>> gruppi) {
		this.listObj = listObj;
		this.gpanel = gpanel;
		this.gruppi = gruppi;
	
	}
	
	@Override
	public void interpreta(String comando) {
		Opzioni opt = Opzioni.ALL;
		new PerimeterCommand(listObj, gruppi, gpanel, -1, opt, "");
	}
}
