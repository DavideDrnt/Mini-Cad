package is.interpreter;

public interface Interpreter {
	void interpreta(String comando);

}
