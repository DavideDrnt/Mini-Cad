package is.interpreter;

import java.awt.geom.Point2D;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import is.command.CommandHandler;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;
import is.specificcommand.MoveCommand;
import is.specificcommand.MoveOffCommand;

public class Move extends Cmd{
	
	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private CommandHandler handler;
	
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	
	private ObjID id;
	private Pos position;
	private boolean mvoff;
	private StringTokenizer st;
	
	public Move (GraphicObjectPanel gpanel, 
			List<AbstractGraphicObject> listObj, Map<Integer, List<AbstractGraphicObject>> gruppi,
			CommandHandler handler, ObjID id, Pos position, boolean mvoff) {
		this.listObj = listObj;
		this.gpanel = gpanel;
		this.gruppi = gruppi;
		this.handler = handler;
		this.id = id;
		this.position = position;
		this.mvoff = mvoff;
	}
	
	@Override
	public void interpreta(String comando) {
		st = new StringTokenizer(comando, " (),");
		st.nextToken();
		id.interpreta(st.nextToken());
		String prefix = id.gerPrefix();
		if(prefix.equalsIgnoreCase("gid")) {//move di un gruppo
			int idObj = id.getId();
			
			String cmdPos = ""+st.nextToken()+","+st.nextToken();//posfloat,posfloat
			
			position.interpreta(cmdPos);
			Point2D.Double coordinate = position.getPos();
			
			if(!mvoff) {// comando mv
				if(gruppi.containsKey(idObj)) {
					handler.handle(new MoveCommand(gruppi.get(idObj), coordinate, gpanel));
				}else {
					JOptionPane.showMessageDialog(null, "Gruppo con id "+idObj+" non presente");
				}
			}else {//comando mvoff
				if(gruppi.containsKey(idObj)) {
					handler.handle(new MoveOffCommand(gruppi.get(idObj), coordinate, gpanel));

				}else {
					JOptionPane.showMessageDialog(null, "Gruppo con id "+idObj+" non presente");
				}
			}
			
		}else if(prefix.equalsIgnoreCase("id")) {//move di un singolo oggetto
			int idObj = id.getId();
			
			String cmdPos = ""+st.nextToken()+","+st.nextToken();//posfloat,posfloat
			
			position.interpreta(cmdPos);
			Point2D.Double coordinate = position.getPos();
			
			if(!mvoff) {// comando mv
				if(gpanel.getList().contains(listObj.get(idObj))) {
					handler.handle(new MoveCommand(listObj.get(idObj), coordinate));

				}else {
					JOptionPane.showMessageDialog(null, "Elemento con id "+idObj+" non presente");
				}
			}else {//comando mvoff
				if(gpanel.getList().contains(listObj.get(idObj))) {
					handler.handle(new MoveOffCommand(listObj.get(idObj), coordinate));

				}else {
					JOptionPane.showMessageDialog(null, "Elemento con id "+idObj+" non presente");
				}
			}
		}
	}

}
