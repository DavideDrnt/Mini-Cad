package is.interpreter;

import java.io.IOException;
import java.io.Reader;
import java.io.StreamTokenizer;

public class AnalizzatoreLessicale {
	private StreamTokenizer st;
	private Simboli simbolo;
	
	private String regexID,regexGID, regexPosFloat, regexNumb;
	
	public AnalizzatoreLessicale(Reader in) {
		st = new StreamTokenizer(in);
		st.resetSyntax();
		st.eolIsSignificant(false);
		st.wordChars('a', 'z');
		st.wordChars('A', 'Z');
		st.wordChars('0', '9');	
		st.whitespaceChars('\u0000', ' ');
		st.ordinaryChar('(');
		st.ordinaryChar(')');
		st.ordinaryChar(',');
		st.ordinaryChar('_');
		st.ordinaryChar('\\');
		st.quoteChar('"');
		
		regexID = "id_\\d+";
		regexGID = "gid_\\d+";
		regexPosFloat = "\\d+\\.\\d+";
		regexNumb = "[0-9]+";
	}
	
	public String getString() {
		return st.sval;
	}
	
	public Simboli prossimoSimbolo() {
		try {
			switch(st.nextToken()) {
			case StreamTokenizer.TT_EOF:
				simbolo = Simboli.EOC;
				break;
			case StreamTokenizer.TT_WORD:
				if(st.sval.equalsIgnoreCase("new")) {
					simbolo = Simboli.NEW;
				} else if(st.sval.equalsIgnoreCase("del")) {
					simbolo = Simboli.DEL;
				}else if(st.sval.equalsIgnoreCase("mv")) {
					simbolo = Simboli.MV;
				}else if(st.sval.equalsIgnoreCase("mvoff")) {
					simbolo = Simboli.MVOFF;
				}else if(st.sval.equalsIgnoreCase("scale")) {
					simbolo = Simboli.SCALE;
				}else if(st.sval.equalsIgnoreCase("ls")) {
					simbolo = Simboli.LS;
				}else if(st.sval.equalsIgnoreCase("grp")) {
					simbolo = Simboli.GRP;
				}else if(st.sval.equalsIgnoreCase("ungrp")) {
					simbolo = Simboli.UNGRP;
				}else if(st.sval.equalsIgnoreCase("area")) {
					simbolo = Simboli.AREA;
				}else if(st.sval.equalsIgnoreCase("perimeter")) {
					simbolo = Simboli.PERIMETER;
				}else if(st.sval.equalsIgnoreCase("all")) {
					simbolo = Simboli.ALL;
				}else if(st.sval.equalsIgnoreCase("groups")) {
					simbolo = Simboli.GROUPS;
				}else if(st.sval.equalsIgnoreCase("circle")) {
					simbolo = Simboli.CIRCLE;
				}else if(st.sval.equalsIgnoreCase("rectangle")) {
					simbolo = Simboli.RECTANGLE;
				}else if(st.sval.equalsIgnoreCase("img")) {
					simbolo = Simboli.IMG;
				}else if(st.sval.equalsIgnoreCase("id")) {
					verObjectID();
				}else if(st.sval.equalsIgnoreCase("gid")) {
					verObjectID();
				}else if(st.sval.matches(regexNumb)) {
					verPosFloat();
				}else {
					simbolo = Simboli.COM_INVALIDO;
				}

				break;
			case '(':
				simbolo = Simboli.TONDA_APERTA;
				break;
			case ')':
				simbolo = Simboli.TONDA_CHIUSA;
				break;
			case ',':
				simbolo = Simboli.VIRGOLA;
				break;
			case '_':
				simbolo = Simboli.UNSCORE;
				break;
			default:
				simbolo = Simboli.COM_INVALIDO;
			}
		}catch(IOException ioe) {
			simbolo = Simboli.EOC;
		}
		return simbolo;
	}
	
	
	public Simboli verObjectID() {
		try {
			String id = ""+st.sval+"_";
			st.nextToken();
			st.nextToken();
			if(st.sval.matches(regexNumb)) {
				id += st.sval;
				if(id.matches(regexID)) {
					simbolo = Simboli.ID;
				}else if(id.matches(regexGID)) {
					simbolo = Simboli.G_ID;
				}
			}else {
				simbolo = Simboli.COM_INVALIDO;
			}

		}catch(IOException ioe) {
			simbolo = Simboli.COM_INVALIDO;
		}
		
		return simbolo;
	}
	
	
	
	public Simboli verPosFloat() {
		try {
			
			String posFloat = ""+st.sval+".";
			st.nextToken();
			st.nextToken();
			if(st.sval.matches(regexNumb)) {
				posFloat += st.sval;
				if(posFloat.matches(regexPosFloat)) {
					simbolo = Simboli.POS_FLOAT;
				}
			}else {
				simbolo = Simboli.COM_INVALIDO;
			}
			
		}catch(Exception e) {
			simbolo = Simboli.COM_INVALIDO;
		}
		return simbolo;
	}
	
}
