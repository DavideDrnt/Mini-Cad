package is.interpreter;

public abstract class Perimeter extends Cmd{

}
