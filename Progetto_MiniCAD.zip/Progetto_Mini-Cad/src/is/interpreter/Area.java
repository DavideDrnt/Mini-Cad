package is.interpreter;

public abstract class Area extends Cmd{

}
