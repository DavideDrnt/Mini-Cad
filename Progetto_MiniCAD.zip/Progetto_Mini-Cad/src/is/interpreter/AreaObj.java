package is.interpreter;

import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;
import is.specificcommand.AreaCommand;

public class AreaObj extends Area{
	
	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	
	private ObjID id;
	private StringTokenizer st;
	
	public AreaObj (GraphicObjectPanel gpanel, 
			List<AbstractGraphicObject> listObj, Map<Integer, List<AbstractGraphicObject>> gruppi,
			ObjID id) {
		this.listObj = listObj;
		this.gpanel = gpanel;
		this.gruppi = gruppi;
		this.id = id;
	}
	
	@Override
	public void interpreta(String comando) {
		st = new StringTokenizer(comando, " (),");
		st.nextToken();
		id.interpreta(st.nextToken());
		int idObj = id.getId();
		String prefix = id.gerPrefix();
		if(prefix.equalsIgnoreCase("id")) {
			Opzioni opt = Opzioni.SINGLE_OBJECT;
			new AreaCommand(listObj, gruppi, gpanel,  idObj, opt, "");
		}else if(prefix.equalsIgnoreCase("gid")){
			Opzioni opt = Opzioni.GRP;
			new AreaCommand(listObj, gruppi, gpanel, idObj, opt, "");
		}
	}

}
