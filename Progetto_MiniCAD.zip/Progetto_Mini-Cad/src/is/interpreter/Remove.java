package is.interpreter;


import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import is.command.CommandHandler;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;
import is.specificcommand.DelCommand;

public class Remove extends Cmd{
	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private CommandHandler handler;
	
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	private IdGroups idGroups;
	
	private ObjID id;
	private StringTokenizer st;
	

	
	// MAP
	public Remove (GraphicObjectPanel gpanel, 
			List<AbstractGraphicObject> listObj, Map<Integer, List<AbstractGraphicObject>> gruppi,
			IdGroups idGroups, CommandHandler handler, ObjID id) {
		this.listObj = listObj;
		this.gpanel = gpanel;
		this.gruppi = gruppi;
		this.idGroups = idGroups;
		this.handler = handler;
		this.id = id;
	}
	
	@Override
	public void interpreta(String comando) {
		st = new StringTokenizer(comando, " (),");
		st.nextToken();
		id.interpreta(st.nextToken());
		String prefix = id.gerPrefix();
		int del = id.getId();
		if(prefix.equalsIgnoreCase("gid")) {
			
			if(gruppi.containsKey(del)) {
				handler.handle(new DelCommand(gruppi.get(del), gpanel, gruppi, idGroups, del));
			}
			
		}else if(prefix.equalsIgnoreCase("id")) {
			boolean trovato = false;
			for(AbstractGraphicObject ago : listObj) {
				if(ago.getID() == del && gpanel.getList().contains(ago)) {
					handler.handle(new DelCommand(ago, gpanel));
					trovato = true;
					break;
				}
			}
			if(!trovato) {
				JOptionPane.showMessageDialog(null, "Elemento con id "+del+" non trovato");
			}
		}
		
		gpanel.repaint();
			
	}
}
