package is.interpreter;

public abstract class Cmd implements Interpreter{


}
