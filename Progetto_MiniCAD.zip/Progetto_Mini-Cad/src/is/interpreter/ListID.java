package is.interpreter;

import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

public class ListID implements Interpreter{
	
	private List<ObjID> objects;
	private StringTokenizer st;
	
	public ListID(ObjID o) {
		if(objects == null) {
			objects = new LinkedList<>();
		}
		objects.add(o);
	}
	@Override
	public void interpreta(String comando) {
		st = new StringTokenizer(comando, " ,");
		st.nextToken();
		for(ObjID obj : objects) {
			obj.interpreta(st.nextToken());
		}
		
	}
	
	public void addObjID(ObjID o) {
		objects.add(o);
	}
	
	public List<ObjID> getList(){return objects;}

}
