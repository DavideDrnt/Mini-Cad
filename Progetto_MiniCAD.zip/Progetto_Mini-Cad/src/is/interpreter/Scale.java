package is.interpreter;

import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import is.command.CommandHandler;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.view.GraphicObjectPanel;
import is.specificcommand.ScaleCommand;

public class Scale extends Cmd{

	private GraphicObjectPanel gpanel;
	private List<AbstractGraphicObject> listObj;
	private CommandHandler handler;
	
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	
	private ObjID id;
	private PosFloat factor;
	
	private StringTokenizer st;
	
	public Scale (GraphicObjectPanel gpanel, 
			List<AbstractGraphicObject> listObj, Map<Integer, List<AbstractGraphicObject>> gruppi,
			CommandHandler handler, ObjID id, PosFloat factor) {
		this.listObj = listObj;
		this.gpanel = gpanel;
		this.gruppi = gruppi;
		this.handler = handler;
		this.id = id;
		this.factor = factor;
	}
	
	@Override
	public void interpreta(String comando) {
		st = new StringTokenizer(comando, " (),");
		st.nextToken();
		id.interpreta(st.nextToken());
		String prefix = id.gerPrefix();
		if(prefix.equalsIgnoreCase("gid")) {//scale di un gruppo
			int idObj = id.getId();
			
			factor.interpreta(st.nextToken());
			double scale = factor.getPos();
			if(gruppi.containsKey(idObj)) {
				handler.handle(new ScaleCommand(gruppi.get(idObj), gpanel, scale));
			}else {
				JOptionPane.showMessageDialog(null,  "Gruppo con id " +idObj+" non presente");
			}
		}else if(prefix.equalsIgnoreCase("id")) {//scale di un singolo oggetto
			int idObj = id.getId();
			factor.interpreta(st.nextToken());
			double scale = factor.getPos();
			if(gpanel.getList().contains(listObj.get(idObj))) {
				handler.handle(new ScaleCommand(listObj.get(idObj), scale));
			}else {
				JOptionPane.showMessageDialog(null,  "Elemento con id " +idObj+" non presente");
			}
		}
		
		
		gpanel.repaint();
	}
}
