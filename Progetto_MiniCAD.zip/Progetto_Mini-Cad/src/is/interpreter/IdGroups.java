package is.interpreter;

public class IdGroups {
	private static int idNuovoGruppo;
	
	public IdGroups() {
		idNuovoGruppo = 0;
	}
	
	public int getNextGrpId() {return idNuovoGruppo;}
	public void incrementa() {idNuovoGruppo++;}
	public void decrementa() {idNuovoGruppo--;}

}
