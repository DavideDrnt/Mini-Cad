package is.interpreter;

import java.awt.geom.Point2D;
import java.util.StringTokenizer;

public class Pos implements Interpreter{
	private Point2D.Double coordinate;
	private PosFloat x,y;
	
	public Pos(PosFloat x, PosFloat y) {
		this.x = x;
		this.y = y;
	}

	@Override
	public void interpreta(String comando) {//riceve posfloat,posfloat
		StringTokenizer st = new StringTokenizer(comando, " ,");
		x.interpreta(st.nextToken());
		double xCord = x.getPos();
		y.interpreta(st.nextToken());
		double yCord = y.getPos();
		
		coordinate = new Point2D.Double(xCord, yCord);
	}
	
	public Point2D.Double getPos(){return coordinate;}

}
