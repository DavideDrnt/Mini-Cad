package is.interpreter;

public class SyntaxException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SyntaxException() {
		
	}
	
	public SyntaxException(String msg) {
		super(msg);
	}
}
