package is.interpreter;

public class Type implements Interpreter{
	
	private String tipo;
	
	

	@Override
	public void interpreta(String comando) {
		tipo = comando;
	}
	
	public String getType() {return tipo;}

}
