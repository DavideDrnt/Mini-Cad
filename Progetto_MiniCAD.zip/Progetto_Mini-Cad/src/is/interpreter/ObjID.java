package is.interpreter;

public class ObjID implements Interpreter{
	private String[] parti;
	

	
	@Override
	public void interpreta(String comando) {
		parti = comando.split("_");
		
		
	}
	
	public int getId() {return Integer.parseInt(parti[1]);}
	public String gerPrefix() {return parti[0];}
	

}
