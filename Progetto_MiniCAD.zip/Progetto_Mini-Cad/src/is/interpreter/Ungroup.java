package is.interpreter;

import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import is.command.CommandHandler;
import is.shapes.model.AbstractGraphicObject;
import is.specificcommand.UnGroupCommand;

public class Ungroup extends Cmd{
	
	private Map<Integer, List<AbstractGraphicObject>> gruppi;
	private CommandHandler handler;
	private IdGroups idGroups;
	
	private ObjID id;
	private StringTokenizer st;
	
	public Ungroup (Map<Integer, List<AbstractGraphicObject>> gruppi,
			IdGroups idGroups, CommandHandler handler, ObjID id) {
		this.gruppi = gruppi;
		this.idGroups = idGroups;
		this.handler = handler;
		this.id = id;
	}
	
	@Override
	public void interpreta(String comando) {
		st = new StringTokenizer(comando, " (),");
		st.nextToken();
		id.interpreta(st.nextToken());
		String prefix = id.gerPrefix();
		try {
			if(prefix.equalsIgnoreCase("gid")) {	
				int idObj = id.getId();	
				if(gruppi.containsKey(idObj)) {
					UnGroupCommand ungrp = new UnGroupCommand(idObj, gruppi, idGroups);
					handler.handle(ungrp);
				}
			}
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Comando ungrp non corretto");
		}
		
	}
}
