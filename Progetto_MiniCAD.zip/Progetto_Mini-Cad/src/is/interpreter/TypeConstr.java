package is.interpreter;

import java.util.StringTokenizer;


public class TypeConstr implements Interpreter{

	private StringTokenizer st;
	private PosFloat raggio;
	private Pos dimensioni;
	private Path percorso;
	private String tipo;
	
	public TypeConstr(PosFloat raggio) {
		this.raggio = raggio;
		this.dimensioni = null;
		this.percorso = null;
	}
	
	public TypeConstr(Pos dimensioni) {
		this.raggio = null;
		this.dimensioni = dimensioni;
		this.percorso = null;
	}
	
	public TypeConstr(Path percorso) {
		this.raggio = null;
		this.dimensioni = null;
		this.percorso = percorso;
	}
	
	@Override
	public void interpreta(String comando) {
		st = new StringTokenizer(comando, " \"( ),");
		st.nextToken();
		st.nextToken();// otteniamo il tipo dell'oggetto da creare
		if(raggio != null) {
			
			raggio.interpreta(st.nextToken());//posfloat completo
			tipo = "circle";
		
		}else if(dimensioni != null) {
			
			String dim = ""+st.nextToken()+","+st.nextToken();
			
			dimensioni.interpreta(dim);
			tipo = "rectangle";
		
		}else if(percorso != null) {
			
			percorso.interpreta(st.nextToken());
			tipo = "img";
		
		}else {
			throw new IllegalArgumentException();
		}
		
	}
	
	public String getType(){return tipo;}
	
	public PosFloat getRaggio(){return raggio;}
	public Pos getDimensioni(){return dimensioni;}
	public Path getPercorso(){return percorso;}
	

}
