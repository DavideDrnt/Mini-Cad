package is.main;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.StringReader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;

import is.command.HistoryCommandHandler;
import is.interpreter.Cmd;
import is.interpreter.IdGroups;
import is.interpreter.ParserCmd;
import is.shapes.model.AbstractGraphicObject;
import is.shapes.model.CircleObject;
import is.shapes.model.ImageObject;
import is.shapes.model.RectangleObject;
import is.shapes.view.CircleObjectView;
import is.shapes.view.GraphicObjectPanel;
import is.shapes.view.GraphicObjectViewFactory;
import is.shapes.view.ImageObjectView;
import is.shapes.view.RectangleObjectView;

public class MiniCad {
	private final static GraphicObjectPanel gpanel = new GraphicObjectPanel();
	private static List<AbstractGraphicObject> listObj = new LinkedList<>();	
	private final static HistoryCommandHandler handler = new HistoryCommandHandler();
	
	private static Map<Integer, List<AbstractGraphicObject>> gruppi = new HashMap<>();
	private static IdGroups idGroups = new IdGroups();//id prossimo gruppo creato
	
	public MiniCad() {
		JFrame f = new JFrame();
		
		JTextField jtf = new JTextField(50);
		
		jtf.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				StringReader in = new StringReader(jtf.getText());
				ParserCmd parser = new ParserCmd(gpanel, listObj, gruppi, idGroups, handler, in);
				Cmd comando = parser.getComando();
				comando.interpreta(jtf.getText());
				jtf.setText("");
			}
		});
		
		JToolBar toolbar = new JToolBar();
		
		JButton helpButton = new JButton("Help");
		JButton undoButton = new JButton("Undo");
		JButton redoButton = new JButton("Redo");
		 
		helpButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Lista Comandi:\n"
							+ "<create>::= new <typeconstr> <pos>\r\n"
							+ "<remove>::= del <objID>\r\n"
							+ "<move>::= mv <objID> <pos> | mvoff <objID> <pos> \r\n"
							+ "<scale>::= scale <objID> <posfloat>\r\n"
							+ "<list>::= ls <objID>| ls <type> | ls all | ls groups\r\n"
							+ "<group>::= grp <listID>\r\n"
							+ "<ungroup>::= ungrp <objID>\r\n"
							+ "<area>::= area <objID>| area <type> | area all\r\n"
							+ "<perimeter>::= perimeter <objID>| perimeter <type> | perimeter all\r\n"
							+ "<pos>::=( <posfloat> , <posfloat> )\r\n"
							+ "<typeconstr>::= circle (<posfloat>) | rectangle <pos> | img (<path>)\r\n"
							+ "<type>::= circle | rectangle | img\r\n"
							+ "<listID>::= <objID> { , <objID> }\r\n"
							+ "<posfloat>:= numero floating point non negativo\r\n"
							+ "<objID>:= un identificatore\r\n"
							+ "<path>:= un percorso valido di file\r\n");
			}
		});
		undoButton.addActionListener(evt -> handler.undo());
		redoButton.addActionListener(evt -> handler.redo());
		
		toolbar.add(helpButton);
		toolbar.add(undoButton);
		toolbar.add(redoButton);
		
		gpanel.setPreferredSize(new Dimension(400, 400));
		GraphicObjectViewFactory.FACTORY.installView(RectangleObject.class, new RectangleObjectView());
		GraphicObjectViewFactory.FACTORY.installView(CircleObject.class, new CircleObjectView());
		GraphicObjectViewFactory.FACTORY.installView(ImageObject.class, new ImageObjectView());
		
		f.add(toolbar, BorderLayout.NORTH);
		f.add(new JScrollPane(gpanel), BorderLayout.CENTER);
		
		JPanel controlPanel = new JPanel(new FlowLayout());
		
		controlPanel.add(jtf);
		f.getContentPane().add(controlPanel, BorderLayout.SOUTH);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.pack();
		f.setLocation(300, 300);
		f.setVisible(true);
		f.setTitle("Mini-Cad");
		
		
	}
}
