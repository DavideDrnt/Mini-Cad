package is.main;

public class MiniCadTest {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		MiniCad miniCad = new MiniCad();
	}

}
