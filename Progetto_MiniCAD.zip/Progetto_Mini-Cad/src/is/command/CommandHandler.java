package is.command;

public interface CommandHandler {
	void handle(Command c);

}
