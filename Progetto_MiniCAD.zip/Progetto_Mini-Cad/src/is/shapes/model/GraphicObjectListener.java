package is.shapes.model;

public interface GraphicObjectListener {
	void graphicChanged(GraphicEvent e);
}
