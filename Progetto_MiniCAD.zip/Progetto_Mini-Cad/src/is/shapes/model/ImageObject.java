package is.shapes.model;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.geom.Dimension2D;
import java.awt.geom.Point2D;

import javax.swing.ImageIcon;

public class ImageObject extends AbstractGraphicObject{
	private double factor = 1.0;
	private final Image image;
	private Point2D position;
	
	private int id;
	private String path;
	
	public Image getImage() {return image;}
	
	public ImageObject(ImageIcon img, Point2D p) {
		position = new Point2D.Double(p.getX(), p.getY());
		image = img.getImage();
		this.path = img.getDescription();
	}
	

	@Override
	public void moveTo(Point2D p) {
		position.setLocation(p);
		notifyListeners(new GraphicEvent(this));
		
	}

	@Override
	public void scale(double factorScale) {
		if(factorScale <= 0) {
			throw new IllegalArgumentException();
		}
		this.factor = factorScale;
		notifyListeners(new GraphicEvent(this));
	}

	@Override
	public boolean contains(Point2D p) {
		double w = (factor * image.getWidth(null)) / 2;
		double h = (factor * image.getHeight(null)) / 2;
		double dx = Math.abs(p.getX() - position.getX());
		double dy = Math.abs(p.getY() - position.getY());
		
		return dx <= w && dy <= h;
	}

	@Override
	public String getType() {
		return "Image";
	}

	@Override
	public Point2D getPosition() {
		return new Point2D.Double(position.getX(), position.getY());
	}

	@Override
	public Dimension2D getDimension() {
		Dimension dim = new Dimension();
		dim.setSize(factor * image.getWidth(null), factor * image.getHeight(null));
		return dim;
	}
	
	@Override 
	public ImageObject clone() {
		ImageObject cloned = (ImageObject) super.clone();
		cloned.position = (Point2D) position.clone();
		return cloned;
	}
	
	@Override
	public void setID(int id) {
		this.id = id;
	}
	
	@Override
	public int getID() {return this.id;}
	
	public String getPath() {return this.path;}
	
	public void setPosition(double x, double y) {
		position.setLocation(x, y);
	}
	
	
}
