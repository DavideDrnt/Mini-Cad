package is.shapes.model;

import java.awt.Dimension;
import java.awt.geom.Dimension2D;
import java.awt.geom.Point2D;

public class RectangleObject extends AbstractGraphicObject{
	
	private Point2D position;
	private Dimension2D dim;
	private int id;
	
	public RectangleObject(Point2D p, double w, double h) {
		if(w <= 0 || h <= 0) {
			throw new IllegalArgumentException();
		}
		dim = new Dimension();
		dim.setSize(w, h);
		position = new Point2D.Double(p.getX(), p.getY());
		
	}

	@Override
	public void moveTo(Point2D p) {
		position.setLocation(p);
		notifyListeners(new GraphicEvent(this));
	}

	@Override
	public void scale(double factorScale) {
		if(factorScale <= 0) {
			throw new IllegalArgumentException();
		}
		dim.setSize(dim.getWidth() * factorScale, dim.getHeight() * factorScale);
		notifyListeners(new GraphicEvent(this));
	}

	@Override
	public boolean contains(Point2D p) {
		double w = dim.getWidth() / 2;
		double h = dim.getHeight() / 2;
		double dx = Math.abs(p.getX() - position.getX());
		double dy = Math.abs(p.getY() - position.getY());
		
		return dx <= w && dy <= h;
	}

	@Override
	public String getType() {
		return "Rectangle";
	}

	@Override
	public Point2D getPosition() {
		return new Point2D.Double(position.getX(), position.getY());
	}

	@Override
	public Dimension2D getDimension() {
		Dimension2D d = new Dimension();
		d.setSize(dim);
		return d;
	}
	
	@Override
	public RectangleObject clone() {
		RectangleObject cloned = (RectangleObject) super.clone();
		cloned.position = (Point2D) position.clone();
		cloned.dim =(Dimension2D) dim.clone();
		return cloned;
	}
	
	@Override
	public void setID(int id) {
		this.id = id;
	}
	
	@Override
	public int getID() {return this.id;}
	
	
	public void setPosition(double x, double y) {
		position.setLocation(x, y);
	}
	
	public void setDimension(int x, int y) {
		dim = new Dimension(x, y);
	}
	
	public double perimeter() {
		return (2 * dim.getHeight() + 2 * dim.getWidth());
	}
	
	public double area() {
		return dim.getHeight() * dim.getWidth();
	}

}
