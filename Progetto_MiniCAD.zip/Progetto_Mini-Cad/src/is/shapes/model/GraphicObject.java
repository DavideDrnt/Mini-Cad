package is.shapes.model;
import java.awt.geom.Dimension2D;
import java.awt.geom.Point2D;

public interface GraphicObject {
	void addGraphicObjectListener(GraphicObjectListener l);
	void removeGraphicObjectListener(GraphicObjectListener l);
	
	void moveTo(Point2D p);
	default void moveTo(double x, double y) {
		moveTo(new Point2D.Double(x, y));
	}
	
	void scale(double factorScale);
	
	boolean contains(Point2D p);
	
	String getType();
	
	
	void setID(int id);
	int getID(); 
	  
	
	Point2D getPosition();
	Dimension2D getDimension();
	
	
}
