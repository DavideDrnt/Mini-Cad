module Progetto_MiniCAD {
	requires java.desktop;
	requires junit;
	
}